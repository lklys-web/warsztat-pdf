'use strict';
// Warsztat PDF – serwer (K-D Sp. z o.o.): wszystkie operacje na serwerze,
// 2 darmowe operacje standardowe dziennie na adres IP, potem płatność (PayU).
const express = require('express');
const multer = require('multer');
const rateLimit = require('express-rate-limit');
const { PDFDocument, degrees, rgb, StandardFonts } = require('pdf-lib');
const fontkit = require('@pdf-lib/fontkit');
const JSZip = require('jszip');
const sharp = require('sharp');
const { execFile } = require('node:child_process');
const crypto = require('node:crypto');
const fs = require('node:fs/promises');
const path = require('node:path');
const { promisify } = require('node:util');
const run = promisify(execFile);

for (const k of ['PAYU_POS_ID', 'PAYU_CLIENT_ID', 'PAYU_CLIENT_SECRET', 'PAYU_SECOND_KEY', 'BASE_URL']) {
  if (!process.env[k]) { console.error('Brak zmiennej środowiskowej: ' + k); process.exit(1); }
}
const { PAYU_POS_ID, PAYU_CLIENT_ID, PAYU_CLIENT_SECRET, PAYU_SECOND_KEY, BASE_URL, DATA_DIR = '/data', PORT = 3000 } = process.env;
const PAYU_BASE = process.env.PAYU_BASE_URL || (process.env.PAYU_ENV === 'production' ? 'https://secure.payu.com' : 'https://secure.snd.payu.com');
const FONT_BOLD = process.env.FONT_BOLD || '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf';

// ---- Cennik (grosze, brutto z VAT). Zmiana ceny = tu + public/app.js + regulamin pkt 4 ----
const FREE_PER_DAY = 2;               // darmowe operacje standardowe na dobę (czas polski) na adres IP
const STD_PRICE = 399;                // operacja standardowa ponad limit
const COMP_PRICE = { mid: 399, high: 499, target: 499 };   // kompresja płatna zawsze (target = do zadanego rozmiaru)
const GS = { light: '/printer', mid: '/ebook', high: '/screen' };
const TOOL_NAMES = {
  merge: 'Scalanie PDF', split: 'Wyodrębnianie stron PDF', splitall: 'Podział PDF na strony', delete: 'Usuwanie stron PDF',
  order: 'Zmiana kolejności stron PDF', rotate: 'Obracanie PDF', mark: 'Znak wodny w PDF', num: 'Numeracja stron PDF',
  sign: 'Podpis w PDF', img: 'Obrazy do PDF', comp: 'Kompresja PDF',
  pdf2img: 'PDF na obrazy', unlock: 'Usuwanie hasła z PDF', protect: 'Zabezpieczanie PDF hasłem', imgconv: 'Konwersja obrazów'
};
const zl = (g) => (g / 100).toFixed(2).replace('.', ',') + ' zł';

const LINK_TTL = 30 * 60 * 1000;      // link do pobrania: 30 min
const SWEEP_AGE = 45 * 60 * 1000;     // twarde usunięcie plików po 45 min (regulamin: max 60 min)
const MAX_FILES = 20, MAX_FILE_MB = 50, TOTAL_MB = 60, MAXJOBS = 2;
const ORDERS = path.join(DATA_DIR, 'orders');
const TMP = path.join(DATA_DIR, 'tmp');

const P = (id, ext) => path.join(ORDERS, id + ext);
const validId = (id) => /^[a-f0-9]{48}$/.test(id);
const save = (o) => fs.writeFile(P(o.id, '.json'), JSON.stringify(o));
async function load(id) {
  if (!validId(id)) return null;
  try { return JSON.parse(await fs.readFile(P(id, '.json'), 'utf8')); } catch { return null; }
}
async function rmInputs(id) {
  for (const n of await fs.readdir(ORDERS).catch(() => []))
    if (n.startsWith(id + '.in') || ['.sig', '.pw', '.args', '.work'].some((x) => n === id + x)) await fs.rm(path.join(ORDERS, n), { force: true, recursive: true });
}

// ---- Dzienny limit: skrót HMAC(IP + data), tylko w pamięci, kasowany po zmianie doby ----
const QSECRET = process.env.QUOTA_SECRET || crypto.randomBytes(16).toString('hex');
const day = () => new Intl.DateTimeFormat('sv-SE', { timeZone: 'Europe/Warsaw' }).format(new Date());
const used = new Map();
function qkey(req) {
  let ip = req.ip || '';
  if (ip.startsWith('::ffff:')) ip = ip.slice(7);
  if (ip.includes(':')) ip = ip.split(':').slice(0, 4).join(':'); // IPv6: prefiks sieci
  const d = day();
  return d + ':' + crypto.createHmac('sha256', QSECRET).update(d + '|' + ip).digest('hex').slice(0, 32);
}
const left = (k) => Math.max(0, FREE_PER_DAY - (used.get(k) || 0));
const take = (k) => used.set(k, (used.get(k) || 0) + 1);
const giveBack = (k) => { if (k && used.has(k)) used.set(k, Math.max(0, used.get(k) - 1)); };
setInterval(() => { const d = day(); for (const k of used.keys()) if (!k.startsWith(d + ':')) used.delete(k); }, 30 * 60 * 1000).unref();

// ---- Aplikacja ----
const app = express();
app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use((req, res, next) => {
  res.set({
    'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'",
    'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=()'
  });
  if (req.path.startsWith('/api/')) res.set('X-Robots-Tag', 'noindex, nofollow');
  next();
});

// ---- PayU: klient REST API v2.1 ----
let tok = { v: null, exp: 0 };
async function payuToken() {
  if (tok.v && tok.exp > Date.now() + 60000) return tok.v;
  const r = await fetch(PAYU_BASE + '/pl/standard/user/oauth/authorize', {
    method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ grant_type: 'client_credentials', client_id: PAYU_CLIENT_ID, client_secret: PAYU_CLIENT_SECRET })
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok || !j.access_token) throw new Error('PayU auth: ' + r.status);
  tok = { v: j.access_token, exp: Date.now() + (j.expires_in || 600) * 1000 };
  return tok.v;
}
async function payu(method, p, body) {
  const r = await fetch(PAYU_BASE + p, { method, redirect: 'manual',
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + (await payuToken()) },
    body: body ? JSON.stringify(body) : undefined });
  return { status: r.status, j: await r.json().catch(() => ({})), loc: r.headers.get('location') };
}
async function payuRefund(orderId, ext) {
  const r = await payu('POST', '/api/v2_1/orders/' + encodeURIComponent(orderId) + '/refunds',
    { orderId, refund: { description: 'Zwrot za nieudaną operację', extRefundId: 'refund-' + ext } });
  const code = r.j && r.j.status && r.j.status.statusCode;
  if (![200, 201].includes(r.status) || (code && code !== 'SUCCESS')) throw new Error('PayU refund: ' + r.status + ' ' + code);
}
const SIG_ALGOS = { MD5: 'md5', SHA: 'sha1', 'SHA-1': 'sha1', 'SHA-256': 'sha256', 'SHA-384': 'sha384', 'SHA-512': 'sha512' };
function verifyPayu(raw, header) {
  const kv = Object.fromEntries(String(header || '').split(';').map((x) => x.trim().split('=').map((y) => y.trim())).filter((a) => a.length === 2));
  const algo = SIG_ALGOS[String(kv.algorithm || '').toUpperCase()];
  if (!algo || !kv.signature) return false;
  const exp = Buffer.from(crypto.createHash(algo).update(Buffer.concat([raw, Buffer.from(PAYU_SECOND_KEY)])).digest('hex'));
  const got = Buffer.from(String(kv.signature).toLowerCase());
  return exp.length === got.length && crypto.timingSafeEqual(exp, got);
}

// Powiadomienia PayU (podpis liczony z surowego body + drugi klucz). PayU ponawia do skutku – obsługa idempotentna.
app.post('/api/payu/notify', express.raw({ type: '*/*', limit: '1mb' }), async (req, res) => {
  if (!Buffer.isBuffer(req.body) || !verifyPayu(req.body, req.headers['openpayu-signature'])) return res.sendStatus(400);
  let ev; try { ev = JSON.parse(req.body.toString('utf8')); } catch { return res.sendStatus(400); }
  const ord = ev && ev.order;
  if (ord && ord.status === 'COMPLETED' && validId(ord.extOrderId)) {
    const o = await load(ord.extOrderId);
    if (o && String(ord.totalAmount) === String(o.amount) && ord.currencyCode === 'PLN')
      processOrder(o.id, ord.orderId).catch((e) => console.error('processOrder:', e.message));
    else console.error('notify: niezgodna kwota lub brak zamówienia');
  }
  res.sendStatus(200);
});

app.get('/api/quota', (req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json({ free: FREE_PER_DAY, left: left(qkey(req)), price: zl(STD_PRICE) });
});

// ---- Walidacja ----
class UserError extends Error {}
const bad = (m) => { throw new UserError(m); };
async function readHead(p, n) { const fh = await fs.open(p, 'r'); try { const b = Buffer.alloc(n); await fh.read(b, 0, n, 0); return b; } finally { await fh.close(); } }
const isPdf = async (p) => (await readHead(p, 5)).toString('latin1') === '%PDF-';
async function imgKind(p) {
  const b = await readHead(p, 12);
  if (b[0] === 0x89 && b.toString('latin1', 1, 4) === 'PNG') return 'png';
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'jpg';
  if (b.toString('latin1', 0, 4) === 'RIFF' && b.toString('latin1', 8, 12) === 'WEBP') return 'webp';
  if (b.toString('latin1', 0, 3) === 'GIF') return 'gif';
  if (b.toString('latin1', 4, 8) === 'ftyp' && /^(heic|heix|hevc|hevx|heim|heis|mif1|msf1)/.test(b.toString('latin1', 8, 12))) return 'heic';
  return null;
}
function parseRanges(s, n) {
  const out = [];
  for (const part of s.split(',').map((x) => x.trim()).filter(Boolean)) {
    const m = part.match(/^(\d*)\s*-\s*(\d*)$/); let a, b;
    if (m) { a = +m[1] || 1; b = +m[2] || n; } else if (/^\d+$/.test(part)) { a = b = +part; } else bad('Niepoprawny zakres: ' + part);
    if (a < 1 || b > n || a > b) bad('Zakres ' + part + ' wykracza poza dokument (' + n + ' str.).');
    for (let i = a; i <= b; i++) out.push(i - 1);
  }
  if (!out.length) bad('Podaj numery stron.');
  return out;
}
async function pageCount(p) {
  try { return (await PDFDocument.load(await fs.readFile(p))).getPageCount(); }
  catch (e) { bad(/encrypt/i.test(e.message) ? 'Ten PDF jest zabezpieczony hasłem. Zdejmij je najpierw narzędziem „Usuń hasło z PDF” i spróbuj ponownie.' : 'Nie udało się odczytać pliku PDF (może być uszkodzony).'); }
}
async function prepare(tool, raw, files, sig) {
  if (!TOOL_NAMES[tool]) bad('Nieznane narzędzie.');
  const many = ['merge', 'img', 'imgconv'].includes(tool);
  if (tool === 'merge' && files.length < 2) bad('Dodaj co najmniej dwa pliki PDF.');
  if ((tool === 'img' || tool === 'imgconv') && files.length < 1) bad('Dodaj co najmniej jeden obraz.');
  if (!many && files.length !== 1) bad('Wgraj dokładnie jeden plik PDF.');
  if (files.reduce((a, f) => a + f.size, 0) > TOTAL_MB * 1048576) bad('Łączny rozmiar plików przekracza ' + TOTAL_MB + ' MB.');
  for (const f of files) {
    if (tool === 'img' || tool === 'imgconv') {
      const k = await imgKind(f.path);
      if (!k || (k === 'heic' && tool === 'img')) bad(tool === 'img' ? 'Obsługiwane obrazy: JPG, PNG, WebP, GIF. Zdjęcia HEIC zamień najpierw w konwerterze obrazów.' : 'Obsługiwane formaty: JPG, PNG, WebP, GIF, HEIC.');
    }
    else if (!(await isPdf(f.path))) bad('To nie jest plik PDF.');
  }
  const s = (v) => String(v == null ? '' : v).trim();
  const p = {};
  if (tool === 'split' || tool === 'delete') {
    const n = await pageCount(files[0].path); p.ranges = s(raw.ranges).slice(0, 200);
    const idx = parseRanges(p.ranges, n);
    if (tool === 'delete' && new Set(idx).size >= n) bad('Nie można usunąć wszystkich stron.');
  } else if (tool === 'order') {
    const n = await pageCount(files[0].path);
    p.order = s(raw.order).slice(0, 400).split(/[,\s]+/).filter(Boolean).map((x) => +x - 1);
    if (p.order.length !== n || new Set(p.order).size !== n || p.order.some((i) => !Number.isInteger(i) || i < 0 || i >= n))
      bad('Podaj każdą z ' + n + ' stron dokładnie raz.');
  } else if (tool === 'rotate') {
    p.angle = +s(raw.angle); if (![90, 180, 270].includes(p.angle)) bad('Niepoprawny kąt obrotu.');
  } else if (tool === 'mark') {
    p.text = s(raw.text).slice(0, 60); if (!p.text) bad('Wpisz tekst znaku wodnego.');
  } else if (tool === 'num') {
    p.pos = ['c', 'l', 'r'].includes(raw.pos) ? raw.pos : 'c';
  } else if (tool === 'sign') {
    const n = await pageCount(files[0].path);
    p.page = parseInt(s(raw.page), 10); if (!(p.page >= 1 && p.page <= n)) bad('Strona poza zakresem (1–' + n + ').');
    p.place = ['c', 'l', 'r', 'p'].includes(raw.place) ? raw.place : 'r';
    if (p.place === 'p') { p.x = +raw.x; p.y = +raw.y; if (!(p.x >= 0 && p.x <= 1 && p.y >= 0 && p.y <= 1)) bad('Kliknij na podglądzie strony, aby wskazać miejsce podpisu.'); }
    if (!sig || sig.size > 1048576 || (await imgKind(sig.path)) !== 'png') bad('Brak poprawnego podpisu – narysuj go w polu.');
  } else if (tool === 'comp') {
    p.level = s(raw.level); if (!GS[p.level] && p.level !== 'target') bad('Niepoprawny poziom kompresji.');
    if (p.level === 'target') { p.targetKb = parseInt(s(raw.targetKb), 10); if (!(p.targetKb >= 100 && p.targetKb <= 20480)) bad('Podaj docelowy rozmiar od 100 KB do 20 MB.'); }
  }
  if (tool === 'pdf2img') {
    const n = await pageCount(files[0].path);
    if (n > 50) bad('Maksymalnie 50 stron w jednej operacji. Wyodrębnij fragment dokumentu i spróbuj ponownie.');
    p.format = raw.format === 'png' ? 'png' : 'jpg'; p.dpi = [100, 150, 200].includes(+raw.dpi) ? +raw.dpi : 150;
  }
  if (tool === 'imgconv') p.format = raw.format === 'png' ? 'png' : 'jpg';
  if (tool === 'unlock' || tool === 'protect') {
    const pw = String(raw.password == null ? '' : raw.password);
    if (/[\x00-\x1f\x7f]/.test(pw) || pw !== pw.trim()) bad('Hasło nie może zawierać znaków sterujących ani spacji na początku i końcu.');
    if (tool === 'protect') {
      if (pw.length < 4 || pw.length > 64) bad('Hasło musi mieć od 4 do 64 znaków.');
      if (/^[-#@]/.test(pw)) bad('Hasło nie może zaczynać się od znaków - # @.');
    } else {
      if (pw.length < 1 || pw.length > 128) bad('Wpisz hasło do pliku.');
      const af = path.join(TMP, 'chk-' + crypto.randomBytes(8).toString('hex'));
      await fs.writeFile(af, '--password=' + pw + '\n', { mode: 0o600 });
      try { await run('qpdf', ['--check', '@' + af, files[0].path], { timeout: 60000 }); }
      catch (e) { if (e.code !== 3) bad(/password/i.test(String(e.stderr)) ? 'Nieprawidłowe hasło do pliku.' : 'Nie udało się odczytać pliku PDF (może być uszkodzony).'); }
      finally { await fs.rm(af, { force: true }); }
    }
    Object.defineProperty(p, 'secret', { value: pw, enumerable: false }); // hasło nie trafia do JSON zamówienia
  }
  return p;
}
const priceFor = (tool, p, k) => (tool === 'comp' && COMP_PRICE[p.level]) ? COMP_PRICE[p.level] : (left(k) > 0 ? 0 : STD_PRICE);

// ---- Przyjęcie zamówienia ----
const limiter = rateLimit({ windowMs: 60 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false,
  message: { error: 'Zbyt wiele zamówień z tego adresu. Spróbuj ponownie później.' } });
const upload = multer({ dest: TMP, limits: { fileSize: MAX_FILE_MB * 1048576, files: MAX_FILES + 1 } });

app.post('/api/process', limiter, (req, res) => {
  upload.fields([{ name: 'files', maxCount: MAX_FILES }, { name: 'sig', maxCount: 1 }])(req, res, async (err) => {
    const files = (req.files && req.files.files) || [];
    const sig = req.files && req.files.sig && req.files.sig[0];
    const all = sig ? [...files, sig] : files;
    const fail = async (code, msg, extra) => { await Promise.all(all.map((f) => fs.rm(f.path, { force: true }))); return res.status(code).json({ error: msg, ...extra }); };
    if (err) return fail(400, err.code === 'LIMIT_FILE_SIZE' ? 'Plik jest większy niż ' + MAX_FILE_MB + ' MB.' : 'Nie udało się odebrać plików.');
    let k = null, free = false, id = null;
    try {
      const tool = String(req.body.tool || '');
      let raw = {}; try { raw = JSON.parse(req.body.params || '{}'); } catch { /* puste */ }
      const p = await prepare(tool, raw, files, sig);
      k = qkey(req);
      const price = priceFor(tool, p, k);
      if (price > 0 && req.body.consent !== '1')
        return fail(402, 'Ta operacja jest płatna.', { needsPayment: true, price: zl(price) });
      if (price === 0) { take(k); free = true; } // synchronicznie – bez wyścigu o limit

      id = crypto.randomBytes(24).toString('hex');
      for (let i = 0; i < files.length; i++) await fs.rename(files[i].path, P(id, '.in' + i));
      if (sig) await fs.rename(sig.path, P(id, '.sig'));
      if (p.secret) await fs.writeFile(P(id, '.pw'), p.secret, { mode: 0o600 });
      const o = { id, tool, params: p, n: files.length, size: files.reduce((a, f) => a + f.size, 0),
        status: free ? 'queued' : 'awaiting_payment', created: Date.now(), amount: price };
      if (free) {
        o.quotaKey = k; await save(o);
        processOrder(id, null).catch((e) => console.error('processOrder:', e.message));
        return res.json({ id, url: '/zamowienie/' + id });
      }
      const label = TOOL_NAMES[tool] + (tool === 'comp' ? ({ high: ' – mocna', target: ' – do zadanego rozmiaru' }[p.level] || (p.level === 'mid' ? ' – średnia' : '')) : '');
      const ip = (req.ip || '127.0.0.1').replace(/^::ffff:/, '');
      const r = await payu('POST', '/api/v2_1/orders', {
        notifyUrl: BASE_URL + '/api/payu/notify', continueUrl: BASE_URL + '/zamowienie/' + id, customerIp: ip,
        merchantPosId: PAYU_POS_ID, description: label.slice(0, 50), currencyCode: 'PLN', totalAmount: String(price),
        extOrderId: id, validityTime: 1800, products: [{ name: label, unitPrice: String(price), quantity: '1' }]
      });
      const payUrl = r.j.redirectUri || r.loc;
      if (![200, 201, 302].includes(r.status) || !payUrl) throw new Error('PayU order: ' + r.status);
      o.payuOrderId = r.j.orderId; await save(o);
      res.json({ url: payUrl });
    } catch (e) {
      if (free) giveBack(k);
      if (id) await rmInputs(id);
      if (e instanceof UserError) return fail(400, e.message);
      console.error('process:', e.message);
      return fail(500, 'Nie udało się przyjąć zamówienia. Spróbuj ponownie.');
    }
  });
});

// ---- Wykonanie operacji ----
let active = 0; const waiting = [];
const slot = () => new Promise((r) => { const go = () => { active++; r(); }; active < MAXJOBS ? go() : waiting.push(go); });
const release = () => { active--; const n = waiting.shift(); if (n) n(); };
const busy = new Set();

// Jeden obraz -> plik graficzny, wiele -> archiwum ZIP (obrazy są już skompresowane, więc bez ponownej kompresji)
async function packImages(dir, ext, out, zipName) {
  const names = (await fs.readdir(dir)).filter((n) => n.endsWith('.' + ext)).sort((a, b) => parseInt(a.replace(/\D/g, ''), 10) - parseInt(b.replace(/\D/g, ''), 10));
  if (!names.length) return { ok: false };
  if (names.length === 1) { const b = await fs.readFile(path.join(dir, names[0])); await fs.writeFile(out, b); return { ok: true, size: b.length, name: names[0] }; }
  const z = new JSZip();
  for (const n of names) z.file(n, await fs.readFile(path.join(dir, n)), { compression: 'STORE' });
  const b = await z.generateAsync({ type: 'uint8array' }); await fs.writeFile(out, b);
  return { ok: true, size: b.length, name: zipName };
}

async function runTool(o) {
  const ins = Array.from({ length: o.n }, (_, i) => P(o.id, '.in' + i)), out = P(o.id, '.out'), p = o.params;
  const rd = async (f) => PDFDocument.load(await fs.readFile(f), { ignoreEncryption: true });
  const done = async (bytes, name) => { await fs.writeFile(out, bytes); return { ok: true, size: bytes.length, name }; };
  const pick = async (idx) => { const s = await rd(ins[0]); const d = await PDFDocument.create(); (await d.copyPages(s, idx)).forEach((pg) => d.addPage(pg)); return d; };
  switch (o.tool) {
    case 'merge': {
      const d = await PDFDocument.create();
      for (const f of ins) { const s = await rd(f); (await d.copyPages(s, s.getPageIndices())).forEach((pg) => d.addPage(pg)); }
      return done(await d.save(), 'scalony.pdf');
    }
    case 'split': { const s = await rd(ins[0]); return done(await (await pick(parseRanges(p.ranges, s.getPageCount()))).save(), 'strony.pdf'); }
    case 'delete': {
      const s = await rd(ins[0]); const del = new Set(parseRanges(p.ranges, s.getPageCount()));
      return done(await (await pick(s.getPageIndices().filter((i) => !del.has(i)))).save(), 'bez-stron.pdf');
    }
    case 'order': return done(await (await pick(p.order)).save(), 'nowa-kolejnosc.pdf');
    case 'splitall': {
      const s = await rd(ins[0]), z = new JSZip();
      for (const i of s.getPageIndices()) { const d = await PDFDocument.create(); d.addPage((await d.copyPages(s, [i]))[0]); z.file('strona-' + (i + 1) + '.pdf', await d.save()); }
      return done(await z.generateAsync({ type: 'uint8array' }), 'strony.zip');
    }
    case 'rotate': {
      const d = await rd(ins[0]);
      d.getPages().forEach((pg) => pg.setRotation(degrees((pg.getRotation().angle + p.angle) % 360)));
      return done(await d.save(), 'obrocony.pdf');
    }
    case 'mark': {
      const d = await rd(ins[0]); d.registerFontkit(fontkit);
      const font = await d.embedFont(await fs.readFile(FONT_BOLD), { subset: true }), c = Math.SQRT1_2;
      for (const pg of d.getPages()) {
        const { width: w, height: h } = pg.getSize(), t100 = font.widthOfTextAtSize(p.text, 100);
        const s = Math.min(120, 100 * (w * 0.7) / t100), tw = t100 * s / 100, th = s * 0.7;
        pg.drawText(p.text, { x: w / 2 - tw / 2 * c + th / 2 * c, y: h / 2 - tw / 2 * c - th / 2 * c, size: s, font,
          color: rgb(0.5, 0.5, 0.5), opacity: 0.3, rotate: degrees(45) });
      }
      return done(await d.save(), 'znak-wodny.pdf');
    }
    case 'num': {
      const d = await rd(ins[0]), f = await d.embedFont(StandardFonts.Helvetica), ps = d.getPages();
      ps.forEach((pg, i) => { const t = (i + 1) + ' / ' + ps.length, w = pg.getWidth(), tw = f.widthOfTextAtSize(t, 10);
        pg.drawText(t, { x: p.pos === 'c' ? (w - tw) / 2 : p.pos === 'r' ? w - tw - 36 : 36, y: 20, size: 10, font: f }); });
      return done(await d.save(), 'numerowany.pdf');
    }
    case 'sign': {
      const d = await rd(ins[0]), im = await d.embedPng(await fs.readFile(P(o.id, '.sig'))), pg = d.getPage(p.page - 1);
      const w = pg.getWidth(), sw = Math.min(180, w * 0.4), sh = sw * im.height / im.width;
      let x = p.place === 'c' ? (w - sw) / 2 : p.place === 'r' ? w - sw - 36 : 36, y = 36;
      if (p.place === 'p') { const h = pg.getHeight(); x = Math.max(0, Math.min(w - sw, p.x * w - sw / 2)); y = Math.max(0, Math.min(h - sh, h - p.y * h - sh / 2)); }
      pg.drawImage(im, { x, y, width: sw, height: sh });
      return done(await d.save(), 'podpisany.pdf');
    }
    case 'img': {
      const d = await PDFDocument.create();
      for (const f of ins) {
        const k = await imgKind(f); let im;
        if (k === 'png') im = await d.embedPng(await fs.readFile(f));
        else if (k === 'jpg') im = await d.embedJpg(await fs.readFile(f));
        else im = await d.embedPng(await sharp(f, { limitInputPixels: 120e6 }).png().toBuffer());
        const sc = Math.min(1, 1200 / Math.max(im.width, im.height)), w = im.width * sc, h = im.height * sc;
        d.addPage([w, h]).drawImage(im, { x: 0, y: 0, width: w, height: h });
      }
      return done(await d.save(), 'obrazy.pdf');
    }
    case 'pdf2img': {
      const dir = P(o.id, '.work'), ext = p.format === 'png' ? 'png' : 'jpg';
      await fs.mkdir(dir, { recursive: true });
      await run('gs', ['-sDEVICE=' + (ext === 'png' ? 'png16m' : 'jpeg'), '-r' + p.dpi, '-dTextAlphaBits=4', '-dGraphicsAlphaBits=4',
        ...(ext === 'jpg' ? ['-dJPEGQ=90'] : []), '-dNOPAUSE', '-dBATCH', '-dQUIET', '-dSAFER', '-sOutputFile=' + path.join(dir, 'strona-%d.' + ext), ins[0]], { timeout: 120000 });
      return packImages(dir, ext, out, 'strony-' + ext + '.zip');
    }
    case 'imgconv': {
      const dir = P(o.id, '.work'), ext = p.format === 'png' ? 'png' : 'jpg';
      await fs.mkdir(dir, { recursive: true });
      for (let i = 0; i < ins.length; i++) {
        const dest = path.join(dir, 'obraz-' + (i + 1) + '.' + ext);
        if ((await imgKind(ins[i])) === 'heic') {
          await run('heif-convert', ['-q', '90', ins[i], dest], { timeout: 60000 });
          if (!(await fs.stat(dest).catch(() => null))) await fs.rename(path.join(dir, 'obraz-' + (i + 1) + '-1.' + ext), dest); // wielo-obrazowe HEIC
        } else {
          let im = sharp(ins[i], { limitInputPixels: 120e6 }).rotate();
          im = ext === 'jpg' ? im.flatten({ background: '#ffffff' }).jpeg({ quality: 90 }) : im.png();
          await im.toFile(dest);
        }
      }
      return packImages(dir, ext, out, 'obrazy-' + ext + '.zip');
    }
    case 'unlock':
    case 'protect': {
      const pw = await fs.readFile(P(o.id, '.pw'), 'utf8'), af = P(o.id, '.args');
      await fs.writeFile(af, (o.tool === 'unlock' ? ['--password=' + pw, '--decrypt'] : ['--encrypt', pw, pw, '256', '--']).join('\n') + '\n', { mode: 0o600 });
      try { await run('qpdf', ['@' + af, ins[0], out], { timeout: 90000 }); }
      catch (e) { if (e.code !== 3 || !(await fs.stat(out).catch(() => null))) throw e; } // kod 3 = ostrzeżenia, plik powstał
      const size = (await fs.stat(out)).size;
      return { ok: size > 0, size, name: o.tool === 'unlock' ? 'bez-hasla.pdf' : 'zabezpieczony.pdf' };
    }
    case 'comp': {
      const gs = (extra) => run('gs', ['-sDEVICE=pdfwrite', '-dCompatibilityLevel=1.5', ...extra, '-dNOPAUSE', '-dBATCH', '-dQUIET', '-dSAFER',
        '-sOutputFile=' + out, ins[0]], { timeout: 90000 });
      const dpi = (r) => ['-dPDFSETTINGS=/screen', '-dDownsampleColorImages=true', '-dDownsampleGrayImages=true',
        '-dColorImageDownsampleType=/Bicubic', '-dGrayImageDownsampleType=/Bicubic',
        '-dColorImageResolution=' + r, '-dGrayImageResolution=' + r, '-dMonoImageResolution=' + Math.max(r * 2, 150)];
      if (p.level !== 'target') {
        await gs(['-dPDFSETTINGS=' + GS[p.level]]);
        const size = (await fs.stat(out)).size;
        if (!(size > 0 && size < o.size * 0.98)) { await fs.rm(out, { force: true }); return { ok: false, reason: 'noreduce' }; }
        return { ok: true, size, name: 'plik-zmniejszony.pdf' };
      }
      const goal = p.targetKb * 1024;
      if (o.size <= goal) return { ok: false, reason: 'target' };
      // kolejne, coraz mocniejsze ustawienia; zatrzymujemy się na pierwszym, który mieści się w limicie
      for (const extra of [['-dPDFSETTINGS=/ebook'], ['-dPDFSETTINGS=/screen'], dpi(60), dpi(40)]) {
        await gs(extra);
        const size = (await fs.stat(out)).size;
        if (size > 0 && size <= goal) return { ok: true, size, name: 'plik-zmniejszony.pdf' };
      }
      await fs.rm(out, { force: true });
      return { ok: false, reason: 'target' };
    }
  }
  return { ok: false };
}

const REF = {
  noreduce: 'Nie udało się zmniejszyć tego pliku (np. jest już zoptymalizowany), więc zwróciliśmy całą płatność. Środki wracają zwykle w ciągu kilku dni roboczych.',
  target: 'Nie udało się osiągnąć wybranego rozmiaru (plik jest już mniejszy albo nie da się go zmniejszyć bez utraty czytelności), więc zwróciliśmy całą płatność. Środki wracają zwykle w ciągu kilku dni roboczych.',
  error: 'Nie udało się przetworzyć pliku (może być uszkodzony lub zabezpieczony hasłem), więc zwróciliśmy całą płatność. Środki wracają zwykle w ciągu kilku dni roboczych.'
};
const FREE_ERR = 'Nie udało się przetworzyć pliku (może być uszkodzony lub zabezpieczony hasłem). Ta próba nie została wliczona do dziennego limitu.';
const FREE_NOREDUCE = 'Nie udało się zmniejszyć tego pliku (np. jest już zoptymalizowany). Ta próba nie została wliczona do dziennego limitu.';
const FAILED = 'Nie udało się przetworzyć pliku ani automatycznie zwrócić płatności. Napisz na www@k-d.com.pl – zwrócimy pieniądze ręcznie.';

async function processOrder(id, pi) {
  const o = await load(id);
  if (!o || !['awaiting_payment', 'queued'].includes(o.status) || busy.has(id)) return; // idempotentnie
  busy.add(id);
  try {
    o.status = 'processing'; o.payuOrderId = pi || o.payuOrderId || null; await save(o);
    let r = { ok: false, reason: 'error' };
    await slot();
    try { r = await runTool(o); } catch (e) { console.error('tool ' + o.tool + ':', String(e.message).split('\n')[0]); }
    finally { release(); }
    if (r.ok) {
      Object.assign(o, { status: 'ready', after: r.size, outName: r.name, expires: Date.now() + LINK_TTL });
    } else {
      await fs.rm(P(id, '.out'), { force: true });
      const reason = ['noreduce', 'target'].includes(r.reason) ? r.reason : 'error';
      if (pi) {
        try { await payuRefund(pi, id); o.status = 'refunded'; o.message = REF[reason]; }
        catch (e) { console.error('refund:', e.message); o.status = 'failed'; o.message = FAILED; }
      } else { giveBack(o.quotaKey); o.status = 'error'; o.message = reason === 'noreduce' ? FREE_NOREDUCE : FREE_ERR; }
    }
    await rmInputs(id); delete o.quotaKey; await save(o);
  } finally { busy.delete(id); }
}

// ---- Status i pobranie ----
app.get('/api/order/:id', async (req, res) => {
  res.set('Cache-Control', 'no-store');
  const o = await load(req.params.id);
  if (!o || (o.status === 'ready' && o.expires < Date.now()))
    return res.json({ status: 'gone', message: 'To zamówienie wygasło lub nie istnieje. Pliki są usuwane po upływie czasu ważności linku.' });
  res.json({ status: o.status, tool: o.tool, before: Math.round(o.size / 1024), after: o.after ? Math.round(o.after / 1024) : null,
    name: o.outName || null, expires: o.expires || null, message: o.message || null });
});
app.get('/api/download/:id', async (req, res) => {
  res.set('Cache-Control', 'no-store');
  const o = await load(req.params.id);
  if (!o || o.status !== 'ready' || o.expires < Date.now()) return res.status(404).type('text').send('Link wygasł.');
  res.download(P(o.id, '.out'), o.outName || 'wynik.pdf');
});
app.get('/healthz', (req, res) => res.send('ok'));
const PUB = path.join(__dirname, 'public');
app.get('/zamowienie/:id', (req, res) => { res.set('X-Robots-Tag', 'noindex, nofollow'); res.sendFile(path.join(PUB, 'zamowienie.html')); });
// jeden adres na stronę: /x.html -> /x (bez duplikatów w Google)
app.use((req, res, next) => {
  if (req.path.endsWith('.html')) {
    const q = req.url.slice(req.path.length), p = req.path.replace(/\/?index\.html$/, '/').replace(/\.html$/, '');
    return res.redirect(301, (p || '/') + q);
  }
  next();
});
app.use(express.static(PUB, { extensions: ['html'], maxAge: '1h' }));
app.use((req, res) => res.status(404).sendFile(path.join(PUB, '404.html')));

async function sweep() {
  for (const dir of [ORDERS, TMP]) {
    for (const n of await fs.readdir(dir).catch(() => [])) {
      try { const st = await fs.stat(path.join(dir, n)); if (Date.now() - st.mtimeMs > SWEEP_AGE) await fs.rm(path.join(dir, n), { force: true, recursive: true }); } catch { /* znikł */ }
    }
  }
}
(async () => {
  await fs.mkdir(ORDERS, { recursive: true }); await fs.mkdir(TMP, { recursive: true });
  await sweep(); setInterval(() => sweep().catch(() => {}), 5 * 60 * 1000).unref();
  app.listen(PORT, () => console.log('Warsztat PDF nasłuchuje na :' + PORT));
})();
