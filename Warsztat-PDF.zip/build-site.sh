#!/bin/sh
# Buduje całą witrynę (strony narzędzi, poradniki, sitemap, robots, dokumenty prawne). Wymaga python3 i pandoc.
set -e
cd "$(dirname "$0")"
python3 tools/build_site.py
