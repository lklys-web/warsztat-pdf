---
title: Rejestr czynności przetwarzania danych osobowych (art. 30 ust. 1 RODO) – Warsztat PDF
lang: pl
---

**Administrator:** K-D Sp. z o.o., Al. Zwycięstwa 241/13, 81-521 Gdynia, KRS 0001240474, NIP 5862430327, kontakt: www@k-d.com.pl
**Inspektor ochrony danych:** nie wyznaczono *(do potwierdzenia przez Administratora, czy wyznaczenie jest wymagane)*
**Wersja z dnia:** 07.11.2026

| Lp. | Czynność | Cel | Kategorie osób | Kategorie danych | Odbiorcy | Przekazanie poza EOG | Termin usunięcia | Środki bezpieczeństwa |
|---|---|---|---|---|---|---|---|---|
| 1 | Wykonywanie operacji na plikach (bezpłatnych i płatnych) | Wykonanie umowy (art. 6 ust. 1 lit. b) | Użytkownicy serwisu (konsumenci i przedsiębiorcy) | Pliki PDF/obrazy (mogą zawierać dane dowolnej kategorii – przetwarzane wyłącznie technicznie), rysunek podpisu, hasła do plików (tymczasowo, tylko na czas operacji), parametry operacji, identyfikator zamówienia, daty, zgody | home.pl (hosting) | Nie (serwer w EOG – *do potwierdzenia*) | Wejściowe: po przetworzeniu; wynikowe: do 30 min od wykonania, max 60 min od przesłania | HTTPS, losowy identyfikator zamówienia, kontener bez uprawnień, automatyczne czyszczenie co 5 min, limity zamówień |
| 2 | Obsługa płatności i zwrotów | Umowa i obowiązek prawny (art. 6 ust. 1 lit. b, c) | Płatnicy | Kwota, status, identyfikator płatności, adres IP płatnika (bez danych kartowych) | PayU S.A.; księgowość | Nie (*do potwierdzenia w dokumentach PayU*) | 5 lat od końca roku obrotowego | Dostęp do panelu PayU, silne hasła, ograniczone uprawnienia |
| 3 | Dokumentacja księgowa i podatkowa | Obowiązek prawny (art. 6 ust. 1 lit. c) | Płatnicy, nabywcy faktur | Dane transakcji; dane z faktury (na żądanie) | Biuro rachunkowe | Nie | 5 lat od końca roku | Zgodnie z polityką spółki |
| 4 | Logi serwera | Bezpieczeństwo (art. 6 ust. 1 lit. f) | Odwiedzający serwis | Adres IP, data/godzina, user-agent | home.pl (hosting) | Nie | do 30 dni (rotacja logów) | Ograniczony dostęp administracyjny, rotacja logów |
| 5 | Korespondencja i reklamacje | Uzasadniony interes (art. 6 ust. 1 lit. f) | Osoby kontaktujące się | Imię, e-mail, treść zgłoszenia | home.pl (poczta) | Nie (*do potwierdzenia w dokumentach home.pl*) | do przedawnienia roszczeń | Zabezpieczona skrzynka e-mail |

**Podmioty przetwarzające (umowy powierzenia / DPA do zawarcia lub potwierdzenia):** PayU (rola: administrator czy podmiot przetwarzający oraz wymagana umowa – potwierdzić w dokumentach PayU), home.pl (hosting i poczta), biuro rachunkowe.
| 6 | Dzienny limit operacji bezpłatnych | Uzasadniony interes – ochrona zasobów (art. 6 ust. 1 lit. f) | Odwiedzający serwis | Skrót HMAC adresu IP + data (w pamięci serwera, bez zapisu na dysku) | Brak | Nie | Do końca doby (czyszczenie co 30 min) | Sekret `QUOTA_SECRET`, brak logowania IP w tym celu |
