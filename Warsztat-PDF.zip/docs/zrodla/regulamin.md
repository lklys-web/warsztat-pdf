---
title: Regulamin serwisu Warsztat PDF
lang: pl
---

[← Wróć do narzędzi](/)

Obowiązuje od dnia: **7 listopada 2026 r.**

## 1. Postanowienia ogólne

1. Regulamin określa zasady korzystania z serwisu internetowego dostępnego pod adresem **warsztat-pdf.pl** („Serwis”) oraz zasady zawierania i wykonywania umów o świadczenie usług płatnych, zgodnie z art. 8 ustawy z dnia 18 lipca 2002 r. o świadczeniu usług drogą elektroniczną.
2. Usługodawcą jest **K-D spółka z ograniczoną odpowiedzialnością** (K-D Sp. z o.o.) z siedzibą w Gdyni, Al. Zwycięstwa 241/13, 81-521 Gdynia, wpisana do rejestru przedsiębiorców Krajowego Rejestru Sądowego pod numerem KRS 0001240474 (Sąd Rejonowy Gdańsk-Północ w Gdańsku, VIII Wydział Gospodarczy KRS), NIP 5862430327, REGON 544702353, kapitał zakładowy **5 000,00** zł, adres e-mail: www@k-d.com.pl („Usługodawca”).
3. Użyte w Regulaminie określenia oznaczają: **Użytkownik** – osoba korzystająca z Serwisu; **Konsument** – Użytkownik będący osobą fizyczną dokonującą czynności prawnej niezwiązanej bezpośrednio z jej działalnością gospodarczą lub zawodową; **Przedsiębiorca** – Użytkownik niebędący Konsumentem; **Usługa płatna** – usługa opisana w pkt 4.
4. Regulamin jest udostępniany nieodpłatnie w Serwisie w postaci umożliwiającej jego pozyskanie, odtwarzanie i utrwalanie.

## 2. Wymagania techniczne

Do korzystania z Serwisu potrzebne są: urządzenie z dostępem do internetu, aktualna przeglądarka (Chrome, Firefox, Safari lub Edge) z włączoną obsługą JavaScript. Do zapłaty za Usługi płatne potrzebna jest ponadto możliwość dokonania płatności online wybraną metodą. Korzystanie z internetu wiąże się ze standardowymi zagrożeniami, takimi jak złośliwe oprogramowanie czy próby wyłudzeń; zalecamy aktualizowanie przeglądarki i oprogramowania zabezpieczającego.

## 3. Operacje i bezpłatny limit dzienny

1. W Serwisie można wykonywać następujące operacje na plikach: scalanie PDF, wyodrębnianie stron, podział na pojedyncze strony (archiwum ZIP), usuwanie stron, zmiana kolejności stron, obracanie, znak wodny, numeracja stron, wstawianie podpisu, zamiana obrazów na PDF, zamiana PDF na obrazy (JPG/PNG), usuwanie hasła z PDF (po podaniu hasła przez Użytkownika), zabezpieczanie PDF hasłem, konwersja obrazów (w tym HEIC) oraz kompresja łagodna („Operacje standardowe”), a także kompresja średnia i mocna („Kompresja płatna”). Jedno wykonanie wybranego narzędzia na przesłanym pliku lub plikach jest jedną „Operacją”.
2. Wszystkie Operacje są wykonywane automatycznie **na serwerze Usługodawcy**. Przesłane pliki są przetwarzane wyłącznie w celu wykonania Operacji i usuwane zgodnie z pkt 6. Miniatury stron wyświetlane przy wyborze stron i podpisie generuje przeglądarka Użytkownika; plik trafia na serwer dopiero po kliknięciu przycisku wykonania Operacji.
3. W każdej dobie (od godz. 0:00 do 24:00 czasu polskiego) Użytkownik może wykonać **bezpłatnie 2 Operacje standardowe**. Limit nie obejmuje Kompresji płatnej. Operacja zakończona niepowodzeniem nie zużywa limitu.
4. Limit jest liczony dla adresu IP, z którego łączy się Użytkownik, w postaci jednokierunkowego skrótu kryptograficznego, który jest usuwany po upływie doby (szczegóły w Polityce prywatności). Użytkownicy łączący się z tego samego adresu IP (np. z sieci firmowej, uczelnianej lub komórkowej) mogą dzielić jeden limit. Usługodawca może zmienić wysokość limitu; zmiana nie dotyczy zamówień już złożonych.
5. Po wyczerpaniu limitu każda kolejna Operacja standardowa jest płatna zgodnie z pkt 4. Serwis informuje o wyczerpaniu limitu i cenie przed złożeniem zamówienia.
6. Umowa o świadczenie Operacji bezpłatnych jest zawierana z chwilą rozpoczęcia korzystania z Serwisu i ulega rozwiązaniu z chwilą jego zakończenia. Użytkownik może w każdej chwili zaprzestać korzystania z Serwisu.

## 4. Usługi płatne

1. Usługami płatnymi są: (a) Operacje standardowe wykonywane po wyczerpaniu dziennego limitu bezpłatnego oraz (b) Kompresja płatna. Ceny:

    | Usługa | Cena brutto (zawiera podatek VAT) |
    |---|---|
    | Operacja standardowa – dwie pierwsze w danej dobie | bezpłatnie |
    | Operacja standardowa – każda kolejna w danej dobie | 3,99 zł |
    | Kompresja średnia | 3,99 zł |
    | Kompresja mocna | 4,99 zł |
    | Kompresja do zadanego rozmiaru (200 KB – 5 MB) | 4,99 zł |

2. Cena dotyczy jednej Operacji na plikach o łącznym rozmiarze do 60 MB (do 50 MB na plik, do 20 plików). Ceny podane są w złotych polskich i zawierają podatek VAT; poza ceną nie są pobierane żadne dodatkowe opłaty.
3. Kompresja płatna (średnia, mocna oraz do zadanego rozmiaru) zmniejsza rozmiar pliku PDF przy użyciu oprogramowania Ghostscript, z zachowaniem warstwy tekstowej. W wariancie „do zadanego rozmiaru” Usługodawca stosuje kolejno coraz mocniejsze ustawienia, aż plik osiągnie wybrany rozmiar; jeżeli rozmiar nie zostanie osiągnięty, stosuje się pkt 6 ust. 4. Kompresja łagodna (Operacja standardowa) zmniejsza plik w mniejszym stopniu, przy wyższej jakości obrazów. Stopień zmniejszenia zależy od zawartości pliku i nie jest gwarantowany; kompresja mocna może obniżyć jakość obrazów.
4. Zamówienie składa się w następujący sposób: (1) wybór narzędzia, plików i ustawień, (2) zaznaczenie oświadczeń, o których mowa w pkt 7 ust. 2, (3) kliknięcie przycisku **„Zamawiam i płacę”**, co oznacza zamówienie z obowiązkiem zapłaty, (4) dokonanie płatności na stronie operatora płatności. Umowa o świadczenie usługi płatnej zostaje zawarta z chwilą złożenia zamówienia, a Usługodawca przystępuje do jej wykonania po otrzymaniu potwierdzenia płatności.

## 5. Płatności

1. Płatności obsługuje **PayU S.A.** z siedzibą w Poznaniu. Dostępne metody płatności (m.in. BLIK, szybkie przelewy online, karty płatnicze) są wyświetlane na stronie płatności. Operator otrzymuje dane niezbędne do realizacji płatności, w tym adres IP płatnika (zob. Polityka prywatności).
2. Dane płatnicze (np. numer karty) są przekazywane bezpośrednio operatorowi płatności; Usługodawca nie ma do nich dostępu.
3. Zamówienie nieopłacone w ciągu 30 minut wygasa, a przesłany plik zostaje usunięty.

## 6. Realizacja usługi i pobranie pliku

1. Po zaksięgowaniu płatności (a w przypadku Operacji bezpłatnych – niezwłocznie po przesłaniu plików) Usługodawca realizuje Operację automatycznie, zwykle w ciągu od kilku do kilkudziesięciu sekund. Po jej wykonaniu w Serwisie pojawia się link do pobrania wyniku, **ważny 30 minut**.
2. Pliki wejściowe są usuwane z serwera niezwłocznie po wykonaniu Operacji, a plik wynikowy – po upływie ważności linku, nie później niż **60 minut** od przesłania. Usługodawca nie tworzy kopii plików Użytkownika i nie analizuje ich zawartości. Hasła podane w narzędziach do usuwania i ustawiania hasła są wykorzystywane wyłącznie do wykonania Operacji i usuwane razem z plikami.
3. Użytkownik odpowiada za pobranie pliku w czasie ważności linku. Link nie jest wysyłany e-mailem, dlatego Użytkownik powinien pozostać na stronie albo do niej wrócić, korzystając z adresu, na który został przekierowany po złożeniu zamówienia.
4. Jeżeli Operacja płatna nie może zostać wykonana (np. plik jest uszkodzony lub zabezpieczony hasłem), a w przypadku kompresji – gdy plik nie zmniejszy się o co najmniej 2% albo nie osiągnie wybranego rozmiaru docelowego, Usługodawca nie dostarcza wyniku i **niezwłocznie zwraca całą zapłaconą kwotę** tą samą metodą płatności. Zwrot jest uznawany na rachunku Użytkownika zwykle w ciągu kilku dni roboczych, zależnie od banku lub wydawcy karty.

## 7. Prawo odstąpienia od umowy (Konsumenci)

1. Konsument co do zasady ma prawo odstąpić od umowy zawartej na odległość w terminie 14 dni bez podania przyczyny. Oświadczenie można złożyć na adres e-mail www@k-d.com.pl lub pisemnie na adres siedziby Usługodawcy; można skorzystać ze wzoru formularza stanowiącego Załącznik nr 1.
2. Przed złożeniem zamówienia na Usługę płatną Konsument potwierdza zaznaczeniem pola wyboru, że: (a) wyraża zgodę na rozpoczęcie świadczenia usługi przed upływem terminu do odstąpienia od umowy, oraz (b) został poinformowany, że po pełnym wykonaniu usługi utraci prawo odstąpienia od umowy.
3. Zgodnie z art. 38 pkt 1 ustawy z dnia 30 maja 2014 r. o prawach konsumenta prawo odstąpienia nie przysługuje w odniesieniu do umowy o świadczenie usług, jeżeli Usługodawca wykonał w pełni usługę za wyraźną zgodą Konsumenta, który został poinformowany przed rozpoczęciem świadczenia o utracie prawa odstąpienia. Ponieważ usługa jest wykonywana automatycznie po płatności, prawo odstąpienia wygasa w praktyce z chwilą dostarczenia linku do pobrania pliku.
4. Jeżeli Konsument odstąpi od umowy przed pełnym wykonaniem usługi, jest zobowiązany do zapłaty za świadczenia spełnione do chwili odstąpienia, na zasadach określonych w ustawie o prawach konsumenta.

## 8. Reklamacje

1. Reklamacje dotyczące Serwisu i Usług płatnych można składać e-mailem na adres www@k-d.com.pl lub pisemnie na adres siedziby Usługodawcy. Zgłoszenie powinno zawierać dane kontaktowe, opis problemu oraz datę, godzinę i kwotę płatności (lub numer płatności z potwierdzenia operatora płatności).
2. Usługodawca rozpatruje reklamację w terminie 14 dni od jej otrzymania i informuje o rozstrzygnięciu na adres e-mail lub adres korespondencyjny podany w zgłoszeniu.
3. Konsumentowi przysługują ustawowe uprawnienia z tytułu niezgodności usługi cyfrowej z umową, określone w ustawie o prawach konsumenta. Postanowienia Regulaminu ich nie wyłączają ani nie ograniczają.

## 9. Obowiązki Użytkownika

Użytkownik zobowiązuje się: korzystać z Serwisu zgodnie z prawem i Regulaminem; przesyłać wyłącznie pliki, do których ma prawo; nie przesyłać treści bezprawnych ani zawierających złośliwe oprogramowanie; nie podejmować działań zakłócających działanie Serwisu, w tym automatycznych masowych zamówień. Usługodawca może ograniczyć liczbę zamówień z jednego adresu IP w jednostce czasu. Narzędzia do usuwania hasła wolno używać wyłącznie do dokumentów, do których Użytkownik ma prawo. Usługodawca nie odzyskuje ani nie łamie haseł: usunięcie hasła jest możliwe tylko po jego podaniu.

## 10. Odpowiedzialność

1. Usługodawca odpowiada za wykonanie usługi z należytą starannością, na zasadach określonych w przepisach prawa.
2. Przetwarzanie nie zmienia pliku oryginalnego, który pozostaje u Użytkownika; zalecamy zachowanie kopii oryginału.
3. W stosunkach z Przedsiębiorcami odpowiedzialność Usługodawcy jest ograniczona do wysokości ceny zapłaconej za daną usługę, a odpowiedzialność za utracone korzyści jest wyłączona, z wyjątkiem szkód wyrządzonych umyślnie.

## 11. Dane osobowe

Zasady przetwarzania danych osobowych oraz informacje o plikach cookies opisuje [Polityka prywatności](/polityka-prywatnosci).

## 12. Pozasądowe rozwiązywanie sporów

Konsument ma możliwość skorzystania z pozasądowych sposobów rozpatrywania reklamacji i dochodzenia roszczeń, w szczególności z mediacji, sądu polubownego przy Wojewódzkim Inspektoracie Inspekcji Handlowej, a także z bezpłatnej pomocy powiatowego (miejskiego) rzecznika konsumentów lub organizacji konsumenckich. Informacje na ten temat są dostępne na stronie Urzędu Ochrony Konkurencji i Konsumentów (uokik.gov.pl). Korzystanie z tych sposobów jest dobrowolne.

## 13. Zmiany Regulaminu

1. Usługodawca może zmienić Regulamin z ważnych przyczyn, w szczególności zmiany przepisów prawa, zmiany zakresu lub cen usług albo względów bezpieczeństwa.
2. Zmiany są ogłaszane w Serwisie z co najmniej 7-dniowym wyprzedzeniem i nie dotyczą zamówień złożonych przed ich wejściem w życie.

## 14. Postanowienia końcowe

1. Do umów zawieranych za pośrednictwem Serwisu stosuje się prawo polskie. Wobec Konsumentów wybór prawa nie pozbawia ich ochrony wynikającej z bezwzględnie obowiązujących przepisów kraju ich zwykłego pobytu.
2. Spory z Przedsiębiorcami rozstrzyga sąd właściwy dla siedziby Usługodawcy; spory z Konsumentami – sąd właściwy według przepisów ogólnych.
3. Kontakt z Usługodawcą: www@k-d.com.pl, K-D Sp. z o.o., Al. Zwycięstwa 241/13, 81-521 Gdynia.

## Załącznik nr 1 – wzór formularza odstąpienia od umowy

*(formularz należy wypełnić i odesłać tylko wtedy, gdy chcesz odstąpić od umowy)*

Adresat: K-D Sp. z o.o., Al. Zwycięstwa 241/13, 81-521 Gdynia, e-mail: www@k-d.com.pl

Ja/My(\*) niniejszym informuję/informujemy(\*) o moim/naszym odstąpieniu od umowy o świadczenie następującej usługi: kompresja pliku PDF (wariant: ……………).

Data zawarcia umowy: ……………  
Imię i nazwisko konsumenta: ……………  
Adres konsumenta: ……………  
Podpis konsumenta (tylko jeżeli formularz jest przesyłany w wersji papierowej): ……………  
Data: ……………

(\*) Niepotrzebne skreślić.
