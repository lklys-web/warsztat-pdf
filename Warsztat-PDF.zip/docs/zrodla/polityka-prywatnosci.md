---
title: Polityka prywatności i informacja o plikach cookies
lang: pl
---

[← Wróć do narzędzi](/)

Obowiązuje od dnia: **7 listopada 2026 r.**

## 1. Administrator danych

Administratorem danych osobowych jest **K-D Sp. z o.o.** z siedzibą w Gdyni, Al. Zwycięstwa 241/13, 81-521 Gdynia, KRS 0001240474, NIP 5862430327, REGON 544702353 („Administrator”). Kontakt w sprawach danych osobowych: **www@k-d.com.pl** lub korespondencyjnie na adres siedziby.

## 2. Twoje pliki

Pliki wybrane do operacji (zarówno bezpłatnych, jak i płatnych) są przesyłane na nasz serwer, przetwarzane automatycznie i usuwane w terminach podanych poniżej. Nie przeglądamy ich zawartości i nie udostępniamy ich nikomu poza dostawcą usług serwerowych (w zakresie technicznego przechowywania). Miniatury stron wyświetlane przy wyborze stron i podpisie generuje Twoja przeglądarka lokalnie – plik trafia na nasz serwer dopiero po kliknięciu przycisku wykonania operacji.

## 3. Jakie dane przetwarzamy, w jakim celu i na jakiej podstawie

| Cel | Dane | Podstawa prawna (RODO) | Okres przechowywania |
|---|---|---|---|
| Wykonanie operacji na plikach (bezpłatnych i płatnych) | plik(i) PDF lub obrazy, parametry operacji (np. zakres stron, tekst znaku wodnego, rysunek podpisu, hasło do pliku w narzędziach do hasła – używane tylko na czas operacji i nieprzechowywane w zapisie zamówienia), identyfikator zamówienia, data i godzina, zgody złożone przy zamówieniu płatnym | art. 6 ust. 1 lit. b (wykonanie umowy) | pliki wejściowe: do zakończenia przetwarzania; plik wynikowy: do 30 minut od wykonania, nie dłużej niż 60 minut od przesłania; metadane zamówienia: do 60 minut |
| Dzienny limit operacji bezpłatnych i zapobieganie nadużyciom | jednokierunkowy skrót kryptograficzny adresu IP (IPv4 w całości, IPv6 – prefiks sieci) wraz z datą, liczba wykorzystanych operacji | art. 6 ust. 1 lit. f (uzasadniony interes: ochrona zasobów Serwisu przed nadużyciami) | do końca doby, usuwany z pamięci serwera zwykle w ciągu godziny po jej zmianie (adres IP nie jest zapisywany w tym celu na dysku) |
| Obsługa płatności i zwrotów | dane transakcji przekazywane przez operatora płatności (kwota, status, identyfikator płatności); nie otrzymujemy numeru karty; operatorowi płatności przekazujemy adres IP płatnika, którego wymaga do realizacji płatności | art. 6 ust. 1 lit. b i c | zgodnie z przepisami podatkowymi i rachunkowymi – 5 lat od końca roku obrotowego |
| Wypełnienie obowiązków podatkowych i księgowych | dane transakcji | art. 6 ust. 1 lit. c | 5 lat od końca roku, w którym powstał obowiązek podatkowy |
| Bezpieczeństwo i zapobieganie nadużyciom (logi serwera, limity zamówień) | adres IP, data i godzina żądania, rodzaj przeglądarki | art. 6 ust. 1 lit. f (uzasadniony interes: bezpieczeństwo Serwisu) | zwykle do 30 dni |
| Reklamacje, obrona i dochodzenie roszczeń | dane podane w zgłoszeniu, korespondencja | art. 6 ust. 1 lit. f | do czasu przedawnienia roszczeń |
| Korespondencja e-mail | adres e-mail, treść wiadomości | art. 6 ust. 1 lit. f | do zakończenia sprawy, a następnie do czasu przedawnienia roszczeń |

Przesłane pliki mogą zawierać dane osobowe (Twoje lub osób trzecich), a rysunek podpisu może stanowić dane osobowe. Przetwarzamy je wyłącznie technicznie, w celu wykonania usługi, bez przeglądania ich zawartości i bez udostępniania innym podmiotom. Prosimy o przesyłanie plików, do których masz prawo.

Podanie danych jest dobrowolne, ale niezbędne do skorzystania z Serwisu. Nie podejmujemy wobec Ciebie decyzji w sposób zautomatyzowany wywołujący skutki prawne i nie prowadzimy profilowania.

## 4. Odbiorcy danych

- **PayU S.A.** z siedzibą w Poznaniu – operator płatności. Przetwarza dane niezbędne do realizacji i rozliczenia płatności (m.in. dane podane na stronie płatności, kwotę, adres IP płatnika) zgodnie z własnymi zasadami przetwarzania danych, dostępnymi na stronie PayU.
- **Dostawca usług serwerowych (hostingu)**: **home.pl S.A.** z siedzibą w Szczecinie – dostawca usług serwerowych (hostingu serwera, na którym działa Serwis) oraz poczty elektronicznej.
- Dostawcy usług księgowych i prawnych – w zakresie niezbędnym do realizacji obowiązków Administratora.
- Organy publiczne – wyłącznie gdy obowiązek taki wynika z przepisów prawa.

## 5. Twoje prawa

Przysługuje Ci prawo dostępu do danych, ich sprostowania, usunięcia, ograniczenia przetwarzania, przenoszenia danych oraz sprzeciwu wobec przetwarzania opartego na uzasadnionym interesie. Aby skorzystać z tych praw, napisz na www@k-d.com.pl. Masz także prawo wniesienia skargi do **Prezesa Urzędu Ochrony Danych Osobowych** (ul. Stawki 2, 00-193 Warszawa).

## 6. Pliki cookies i podobne technologie

1. Serwis nie używa plików cookies analitycznych, marketingowych ani reklamowych i nie ładuje zewnętrznych skryptów śledzących, czcionek ani zasobów z sieci reklamowych. Wszystkie zasoby Serwisu są serwowane z naszego serwera.
2. Serwis nie zapisuje w Twojej przeglądarce informacji niezbędnych do działania poza tymi, które przeglądarka przechowuje w pamięci podczas pracy z narzędziami.
3. Po przejściu do płatności zostaniesz przekierowany na stronę **PayU**, która może zapisywać własne pliki cookies niezbędne do bezpiecznego przeprowadzenia płatności i zapobiegania nadużyciom. Zasady ich stosowania określa PayU.
4. Możesz zarządzać plikami cookies w ustawieniach swojej przeglądarki.

## 7. Bezpieczeństwo

Połączenie z Serwisem jest szyfrowane (HTTPS). Pliki przesłane do przetworzenia są przechowywane tymczasowo w odizolowanym środowisku, dostęp do nich jest ograniczony, a po upływie wskazanych terminów są trwale usuwane. Adres, pod którym pobierzesz plik, zawiera długi, losowy identyfikator – nie udostępniaj go innym osobom.

## 8. Zmiany polityki

Aktualna wersja jest zawsze dostępna w Serwisie. O istotnych zmianach informujemy na stronie głównej.
