# Warsztat PDF – instrukcja wdrożenia (K-D Sp. z o.o.)

Stan paczki: serwer przeszedł test uruchomieniowy na prawdziwych plikach (wszystkie narzędzia poza kompresją, darmowy limit, walidacja, czyszczenie plików, odrzucenie błędnego podpisu webhooka). **Nie testowano** budowania obrazu Dockera, Ghostscripta ani płatności w prawdziwym PayU (kod płatności i zwrotów przeszedł test na symulowanym PayU) – to pierwszy krok na serwerze (sekcja 5).

## 0. Co jest w paczce

| Plik | Do czego |
|---|---|
| `server/server.js` | Serwer: wszystkie narzędzia PDF, dzienny limit 2 operacji (skrót IP), płatności PayU (REST API), powiadomienia z weryfikacją podpisu, kompresja Ghostscriptem, automatyczny zwrot, linki 30-minutowe, czyszczenie plików |
| `public/` | Gotowa witryna: strona główna, 11 stron narzędzi, 3 strony „zmniejsz PDF do X”, cennik, poradniki, `sitemap.xml`, `robots.txt` (generowane) |
| `server/server.js` (nowe narzędzia) | PDF na JPG/PNG (Ghostscript), usuwanie i ustawianie hasła (qpdf, AES-256), konwerter obrazów z HEIC (libheif + sharp), podpis klikany na podglądzie. Obraz Dockera zawiera test dekodowania HEIC przy budowaniu |
| `tools/build_site.py`, `build-site.sh` | Generator witryny: treści stron narzędzi, poradników i dokumentów prawnych. Po zmianie treści uruchom `./build-site.sh` (wymaga python3 i pandoc), potem przebuduj kontener |
| `Dockerfile`, `docker-compose.yml`, `Caddyfile` | Uruchomienie z automatycznym HTTPS (Let's Encrypt) |
| `.env.example` | Konfiguracja (domena, dane punktu płatności PayU) |
| `docs/zrodla/*.md` | Źródła dokumentów (edytujesz tu, potem `./build-site.sh`) |
| `docs/zrodla/rejestr-czynnosci.md` | Wewnętrzny rejestr czynności przetwarzania (art. 30 RODO) – nie publikować |

## 1. Hosting w home.pl

Aplikacja potrzebuje serwera z dostępem root (Docker, Ghostscript), więc zwykły hosting współdzielony nie wystarczy. Skoro korzystasz z home.pl, zamów tam **VPS z Linuxem** (Ubuntu 24.04, min. 2 GB RAM, zalecane 4 GB, 20+ GB dysku). Według zewnętrznego porównania w ofercie jest „VPS Linux XS” (1 vCore, 2 GB RAM) – dla płynnej pracy wybierz raczej większy plan; aktualną ofertę potwierdź w panelu home.pl, bo nie sprawdzałem jej w źródle oficjalnym. Przed zamówieniem sprawdź w dokumentach home.pl: (a) lokalizację centrum danych (dokumenty zakładają Europejski Obszar Gospodarczy), (b) umowę powierzenia przetwarzania danych (home.pl jest dla Ciebie podmiotem przetwarzającym), (c) czy VPS obsługuje Dockera (działa na wirtualizacji KVM z dostępem root; na OpenVZ nie).

**Domena `warsztat-pdf.pl` ma wskazywać na ten VPS.** Poczta i strona `k-d.com.pl` to inna domena i pozostają bez zmian. Na nowej domenie nie jest potrzebna poczta – kontakt idzie na `www@k-d.com.pl`.

## 2. DNS w home.pl

W panelu home.pl, w ustawieniach DNS domeny `warsztat-pdf.pl`:

1. Rekord **A** dla nazwy głównej (`@`, czyli samej domeny) → adres IPv4 VPS.
2. Rekord dla `www` (A na ten sam adres albo CNAME na `warsztat-pdf.pl`) – serwer przekieruje `www` na domenę główną.
3. **Usuń lub zmień istniejące rekordy A/AAAA** wskazujące na inną stronę (np. domyślną stronę home.pl). Jeśli VPS nie ma IPv6, usuń też rekord AAAA.
4. Poczekaj na propagację (zwykle do kilku godzin). Certyfikat HTTPS Caddy pobierze sam, gdy tylko DNS zacznie wskazywać na serwer, a porty 80 i 443 są otwarte.

## 3. PayU

1. Załóż konto firmowe w PayU dla **K-D Sp. z o.o.** PayU zweryfikuje spółkę (KRS, NIP, osoby reprezentujące i beneficjentów rzeczywistych, rachunek bankowy w PLN) oraz stronę internetową, która musi już działać z Regulaminem, Polityką prywatności i danymi firmy. Według jednego z porównań BLIK w PayU uruchamia się po dodatkowej weryfikacji trwającej około 2 tygodni – złóż wniosek z zapasem czasu.
2. W Panelu Menedżerskim utwórz **punkt płatności typu REST API** (najpierw w środowisku sandbox, potem produkcyjnym). Skopiuj: Id punktu płatności (POS ID), `client_id`, `client_secret` oraz **drugi klucz (MD5)** i wpisz je w `.env` (`PAYU_POS_ID`, `PAYU_CLIENT_ID`, `PAYU_CLIENT_SECRET`, `PAYU_SECOND_KEY`). `PAYU_ENV=sandbox` lub `production`.
3. W ustawieniach punktu płatności sprawdź **automatyczny odbiór płatności** i włącz go. Bez tego zamówienia zostają w statusie oczekującym na potwierdzenie, a serwis ich nie zrealizuje. Adres powiadomień (`https://warsztat-pdf.pl/api/payu/notify`) aplikacja podaje sama w każdym zamówieniu – musi być publicznie dostępny przez HTTPS.
4. Włącz metody płatności: BLIK, przelewy online, karty (opcjonalnie Google Pay i Apple Pay).
5. **Opłaty:** według porównań z 2026 r. stawki PayU to ok. 1% za BLIK-a i od ok. 1,6% plus 0,20 zł za karty. To dane nieoficjalne i negocjowalne – poproś PayU o ofertę dla spółki, bo przy cenie 3,99 zł liczy się każdy grosz stałej opłaty. Warto też porównać Przelewy24 i Tpay; zmiana operatora to wymiana jednego pliku w serwerze.

## 4. Serwer (VPS)

```bash
# jako root na nowym VPS (Ubuntu 24.04)
apt update && apt -y upgrade
curl -fsSL https://get.docker.com | sh
ufw allow 22 && ufw allow 80 && ufw allow 443 && ufw --force enable
```

Skopiuj folder projektu na serwer (np. `scp -r pdf-warsztat root@IP:/opt/`), następnie:

```bash
cd /opt/pdf-warsztat
cp .env.example .env && nano .env      # domena, dane PayU, QUOTA_SECRET (openssl rand -hex 16)
docker compose up -d --build
docker compose logs -f app             # ma pojawić się: "nasłuchuje na :3000"
```

## 5. Testy przed uruchomieniem (sandbox PayU)

Powiadomienia PayU przychodzą na publiczny adres, więc testuj na VPS z działającym HTTPS, `PAYU_ENV=sandbox` i danymi punktu płatności z sandboxu.

1. Wybierz *Kompresuj PDF → Średnia*, wgraj PDF większy niż 1 MB, zaznacz zgodę i zapłać danymi testowymi z dokumentacji PayU (developers.payu.com).
2. Po powrocie na stronę ma się pokazać „Gotowe” i działający link. Sprawdź rozmiar i to, czy tekst w pliku da się zaznaczyć.
3. Sprawdź limit: trzy zwykłe operacje (np. obrót) z jednego adresu IP – trzecia musi wymagać zgody i płatności 3,99 zł.
4. Test zwrotu: wgraj do kompresji płatnej PDF zabezpieczony hasłem – ma się zakończyć komunikatem o zwrocie, a w panelu PayU pojawi się zwrot. Jeśli sandbox nie obsługuje zwrotów, sprawdź to na prawdziwej płatności 3,99 zł po przełączeniu na produkcję.
5. Po 45–60 minutach pliki mają zniknąć: `docker compose exec app ls /data/orders`.
6. Przełącz `.env` na `PAYU_ENV=production` i dane produkcyjnego punktu płatności, potem `docker compose up -d`.

## 6. Dokumenty – stan

Uzupełnione z odpisu KRS i od Ciebie: pełna firma, siedziba, KRS, NIP, REGON, kapitał zakładowy (5 000 zł), sąd rejestrowy (Sąd Rejonowy Gdańsk-Północ, VIII Wydział Gospodarczy KRS), adres serwisu **warsztat-pdf.pl**, kontakt `www@k-d.com.pl`, dostawca usług home.pl S.A. oraz data wejścia w życie **7 listopada 2026 r.** (zmień ją w `docs/zrodla/*.md`, jeśli uruchomisz później). **Potwierdź nazwę i adres podmiotu home.pl w swojej umowie.**

Po każdej zmianie źródeł: `./build-site.sh` i `docker compose up -d --build`.

## 7. Formalności (potwierdź z księgową i radcą prawnym)

To jest checklista pytań, a nie porada prawna ani podatkowa:

- **VAT:** ceny w serwisie są brutto z VAT. Ustal stawkę (dla usług elektronicznych zwykle 23%) i sposób dokumentowania sprzedaży B2C (paragon/kasa fiskalna albo zwolnienie dla płatności przez operatora; faktury na żądanie).
- **Klienci z innych krajów UE:** oferta jest kierowana do Polski; zapytaj księgową o procedurę OSS (VAT w kraju konsumenta), jeśli zaczną płacić klienci z zagranicy.
- **Zakres działalności (PKD) – ważne:** w odpisie KRS przeważającą działalnością jest 81.30.Z (tereny zieleni), a pozostałe to roboty inżynieryjne i logistyka (42, 52.10, 52.21, 52.25, 52.26). **Nie ma PKD związanego z usługami IT/przetwarzaniem danych** (np. 63.11.Z – przetwarzanie danych i hosting, 62.01.Z). Zapytaj księgową/prawnika, czy trzeba zgłosić zmianę przedmiotu działalności (KRS, REGON, VAT-R), czy zapis w umowie spółki to dopuszcza i od kiedy możesz sprzedawać usługę. Zrób to przed uruchomieniem sprzedaży.
- **Umowy powierzenia (art. 28 RODO):** PayU – sprawdź w dokumentach, czy działa jako niezależny administrator czy podmiot przetwarzający i czy potrzebna jest umowa; dostawca VPS – sprawdź DPA w regulaminie dostawcy; biuro rachunkowe – własna umowa.
- **Regulamin i polityka prywatności:** warto przekazać do 1–2-godzinnej weryfikacji radcy prawnemu (zwłaszcza zapisy o odstąpieniu od umowy, rozdział 7 regulaminu).
- **Rejestr czynności przetwarzania:** uzupełnij `rejestr-czynnosci.md` i przechowuj wewnętrznie.
- **Cookies:** dopóki nie dodasz analityki ani reklam, baner cookies nie jest potrzebny. Dodanie np. Google Analytics wymaga zgody i zmiany polityki.

## 8. Licencje składników

- **Ghostscript (AGPL):** używany jako osobny program w wierszu poleceń, bez modyfikacji. Jeśli kiedyś zmodyfikujesz Ghostscript albo wbudujesz go w własny kod jako bibliotekę, skonsultuj licencję z prawnikiem (Artifex oferuje licencję komercyjną).
- pdf-lib (MIT), JSZip (MIT), sharp (Apache-2.0), Express (MIT), Caddy (Apache-2.0).

## 9. Utrzymanie

- Aktualizacje systemu co miesiąc: `apt update && apt -y upgrade`, a obrazu: `docker compose build --pull && docker compose up -d`.
- Monitoruj `https://twoja-domena/healthz` (np. UptimeRobot).
- Kopie zapasowe niepotrzebne (aplikacja nie trzyma trwałych danych) – zachowaj tylko plik `.env`.
- Zmiana cen: w trzech miejscach – `server/server.js` (`LEVELS`), `public/app.js` (etykiety) i regulamin pkt 4.

## 10. Jak działa limit dzienny i czego nie robi

- Każdy adres IP (IPv6: prefiks sieci) dostaje 2 darmowe operacje standardowe na dobę (czas polski). Licznik jest w pamięci serwera jako skrót HMAC(IP + data) – **restart serwera zeruje liczniki**, a po zmianie doby stare są kasowane.
- Kompresja średnia i mocna jest płatna od razu. Operacja zakończona błędem nie zużywa limitu (a płatna jest zwracana).
- **Ograniczenia:** użytkownicy za wspólnym adresem IP (firma, uczelnia, sieć komórkowa) dzielą limit, a VPN lub zmiana sieci daje nowy limit. To świadomy kompromis – przy cenach rzędu kilku złotych nie warto budować śledzenia użytkowników, które byłoby problemem z RODO. Jeśli kiedyś będziesz chciał zaostrzyć limit, zrobimy konta użytkowników (e-mail + logowanie), ale to zmienia politykę prywatności.
- Zmiana wysokości limitu lub ceny: `FREE_PER_DAY`, `STD_PRICE`, `COMP_PRICE` w `server/server.js`, etykiety w `public/app.js` i regulamin (pkt 3 i 4).
- Dodatkowo działa limit 30 zamówień na godzinę na adres IP (ochrona przed nadużyciami).

## 11. SEO – plan uruchomienia i rozwoju

**Co jest już w paczce:** osobny adres, tytuł, opis i treść dla każdego narzędzia; strony „zmniejsz PDF do 500 KB / 1 MB / 2 MB”; cennik, „O nas” i „Bezpieczeństwo plików” (sygnały zaufania); 4 poradniki; linkowanie wewnętrzne; `sitemap.xml`, `robots.txt`, adresy kanoniczne, tagi Open Graph, dane strukturalne (WebApplication, Organization, okruszki); przekierowanie `/x.html` na `/x`; własna strona 404; `noindex` dla stron zamówień i API.

**Pierwszy tydzień po uruchomieniu**

1. Google Search Console: dodaj usługę „Domena” `warsztat-pdf.pl` i zweryfikuj ją rekordem TXT w DNS w home.pl.
2. Prześlij `https://warsztat-pdf.pl/sitemap.xml`. W „Sprawdzaniu adresu URL” poproś o zaindeksowanie: strony głównej, `/zmniejsz-pdf`, `/scal-pdf` i `/zmniejsz-pdf-do-2-mb`.
3. Bing Webmaster Tools: zaimportuj witrynę z Search Console.
4. PageSpeed Insights (wersja mobilna) dla `/` i `/zmniejsz-pdf`. Strony nie ładują zewnętrznych skryptów, więc wyniki powinny być dobre.
5. Podmień `public/og.png` na własną grafikę 1200×630, jeśli chcesz (obecna jest prosta, wygenerowana).

**Rozwój treści (co 2 tygodnie nowy poradnik lub strona):** dopisuj do list `GUIDES` i `TARGETS` w `tools/build_site.py`, uruchamiaj `./build-site.sh` i przebuduj kontener (`sitemap.xml` uzupełnia się sam). Pomysły: „Jak zmniejszyć PDF ze skanem”, „Jak zrobić PDF ze zdjęć z telefonu”, „Jak ponumerować strony w PDF”, „Jak dodać znak wodny do dokumentu”, „Jak obrócić stronę w PDF”, „Zmniejsz PDF do 200 KB” i „do 5 MB”. Każda strona musi mieć własną, użyteczną treść. Nie twórz dziesiątek prawie identycznych stron.

**Linki zewnętrzne:** wpisy w polskich katalogach i zestawieniach narzędzi, artykuły gościnne, odpowiedzi na pytania na forach i w społecznościach (zgodnie z ich regulaminami), współpraca z blogami o produktywności, szkołach i HR. Nie kupuj linków i nie korzystaj z sieci blogów.

**Pomiar:** Search Console co miesiąc (wyświetlenia, kliknięcia, pozycje fraz). Analityka bez ciasteczek (np. Plausible lub Umami) jest opcjonalna, ale jej dodanie trzeba opisać w polityce prywatności. Google Analytics wymaga baneru zgody.

**Realistyczne oczekiwania:** na ogólne hasła („scal pdf”) rządzą duzi gracze. Młoda domena zwykle potrzebuje kilku miesięcy, żeby zacząć zdobywać pozycje na frazy długiego ogona. Pierwsze 3–6 miesięcy traktuj jako czas budowania widoczności i zbieraj dane z Search Console. Efekty zależą też od tego, czy użytkownicy dokończą operację: jasny cennik i darmowy limit mają im w tym pomagać.

## 12. Nowe funkcje i co dalej

**W paczce są:** PDF na JPG/PNG, usuwanie hasła (tylko po jego podaniu) i zabezpieczanie hasłem, konwerter obrazów (HEIC, WebP, PNG, JPG, GIF), miniatury stron przy wyodrębnianiu, usuwaniu i zmianie kolejności oraz podpis ustawiany kliknięciem na podglądzie strony. Miniatury działają w przeglądarce (pdf.js serwowany z własnego serwera), a plik trafia na serwer dopiero po kliknięciu operacji.

**Po zbudowaniu obrazu sprawdź:** `docker compose build` kończy się bez błędu (w razie komunikatu „BLAD: ten obraz nie dekoduje HEIC” doinstaluj wtyczkę libde265 dla libheif). Na stronach `/heic-na-jpg`, `/pdf-na-jpg`, `/usun-haslo-z-pdf` wykonaj po jednej operacji, a na `/wyodrebnij-strony-pdf` sprawdź, czy pojawiają się miniatury.

**Następne kroki (kiedy dane z Search Console i płatności potwierdzą popyt):** OCR po polsku (Tesseract, wyższa cena, kolejka zadań), Word/Excel/PowerPoint na PDF (LibreOffice w osobnym, odizolowanym kontenerze), karnety lub kody operacji, faktury na NIP (na początek ręcznie przez `www@k-d.com.pl`). Każda nowa funkcja wymaga dopisania do regulaminu, polityki prywatności i rejestru czynności.

**Reklamy:** nie na starcie. Dopóki ruch jest mały, przychód z reklam byłby symboliczny, a reklamy wymagałyby baneru zgody na ciasteczka, zmian w polityce prywatności i regulaminie, zewnętrznych skryptów (wolniejsza strona, słabsze SEO) oraz rezygnacji z obietnicy „bez reklam i śledzących ciasteczek”. Do rozważenia dopiero przy dużym ruchu i tylko na stronach z poradnikami, nigdy na stronach narzędzi i zamówień.

## 13. Hosting współdzielony (np. home.pl WebFTP) – tryb tymczasowy

Pełny serwis wymaga VPS-a (Docker, Node.js, Ghostscript). Na zwykłym hostingu współdzielonym można opublikować tylko strony statyczne:

- Bez pliku `.htaccess` działa wyłącznie strona główna, a adresy bez `.html` (np. `/scal-pdf`) dają błąd 404. Plik `public/.htaccess` to naprawia (adresy bez `.html`, przekierowanie `/x.html` na `/x`, blokada plików technicznych).
- Do hostingu wgrywaj **tylko zawartość folderu `public/`** (z `.htaccess`), nigdy całego projektu: pliki takie jak `server.js`, `Dockerfile`, `rejestr-czynnosci.md` czy `build_site.py` nie powinny być publiczne.
- Tryb „wkrótce”: `SOON=1 OUT_DIR=/sciezka/wyjsciowa ./build-site.sh` generuje strony, na których zamiast narzędzi jest komunikat „w przygotowaniu”, z `noindex` i `robots.txt` blokującym indeksowanie. Po uruchomieniu VPS-a zbuduj normalną wersję (`./build-site.sh`).

