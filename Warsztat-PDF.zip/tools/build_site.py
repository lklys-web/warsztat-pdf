#!/usr/bin/env python3
"""Generuje statyczną witrynę Warsztat PDF: strony narzędzi, cennik, poradniki, sitemap, robots, 404, zamówienie."""
import html, json, os, shutil, subprocess, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SOON = bool(os.environ.get('SOON'))          # tryb „wkrótce”: strony bez działających narzędzi (np. na hosting statyczny)
PUB_SRC = os.path.join(ROOT, 'public')
PUB = os.environ.get('OUT_DIR') or PUB_SRC
SITE = 'https://warsztat-pdf.pl'
DATE = '2026-11-07'
E = html.escape
EMAIL = 'www@k-d.com.pl'

PANEL = ('<section class="panel" id="panel"><div class="drop" id="drop" tabindex="0" role="button"><strong id="dropT"></strong><span id="dropS"></span></div>'
         '<input type="file" id="inp" hidden><ul id="list"></ul><div id="thumbs" class="thumbs"></div><div class="opts" id="opts"></div><div class="priv" id="quota" style="margin-top:12px"></div>'
         '<button class="go" id="go" disabled></button><div class="msg" id="msg" aria-live="polite"></div></section>')
SOON_PANEL = ('<section class="panel"><p><strong>To narzędzie jest w przygotowaniu.</strong> Serwis zostanie uruchomiony już wkrótce. '
              'Wróć za kilka dni lub zobacz <a href="/">listę narzędzi</a>.</p></section>')
PRICE_NOTE = 'Dwie operacje standardowe dziennie są bezpłatne, każda kolejna kosztuje 3,99 zł brutto. Kompresja średnia kosztuje 3,99 zł, mocna i do zadanego rozmiaru 4,99 zł. Płacisz BLIK-iem, przelewem online lub kartą (PayU). Jeśli operacja się nie uda, płatność wraca automatycznie.'

def T(key, slug, nav, short, title, desc, h1, lead, steps, notes, faq, **kw):
    return dict(key=key, slug=slug, nav=nav, short=short, title=title, desc=desc, h1=h1, lead=lead, steps=steps, notes=notes, faq=faq, **kw)

TOOLS = [
 T('merge','scal-pdf','Scal PDF','Połącz kilka plików w jeden','Scal PDF online – połącz pliki w jeden',
   'Połącz kilka plików PDF w jeden dokument w wybranej kolejności. Dwie operacje dziennie bezpłatnie, pliki są usuwane po 30 minutach.',
   'Scal pliki PDF w jeden dokument','Dodaj kilka plików PDF, ustaw ich kolejność i pobierz jeden gotowy dokument. Strony są kopiowane bez ponownego kompresowania, więc tekst i jakość zostają bez zmian.',
   ['Dodaj co najmniej dwa pliki PDF (do 20 plików, łącznie do 60 MB).','Ustaw kolejność strzałkami przy nazwach plików.','Kliknij „Scal pliki” i pobierz wynik w ciągu 30 minut.'],
   ['Pliki zabezpieczone hasłem trzeba najpierw odblokować.','Chcesz dołączyć zdjęcia? Zamień je najpierw na PDF w narzędziu JPG na PDF.','Po scaleniu możesz dodać numerację stron do całego dokumentu.'],
   [('Czy scalanie obniża jakość dokumentu?','Nie. Strony trafiają do nowego pliku w niezmienionej postaci, bez ponownej kompresji obrazów.'),('Ile plików mogę połączyć naraz?','Do 20 plików o łącznym rozmiarze do 60 MB, przy czym pojedynczy plik może mieć do 50 MB.'),('Czy oryginalne pliki się zmieniają?','Nie. Otrzymujesz nowy plik, a Twoje oryginały zostają na Twoim urządzeniu.')]),
 T('split','wyodrebnij-strony-pdf','Wyodrębnij strony','Zapisz wybrane strony jako nowy plik','Wyodrębnij strony z PDF online',
   'Wybierz strony z dokumentu PDF i zapisz je jako nowy plik. Wpisz zakres, np. 1-3, 5. Dwie operacje dziennie bezpłatnie.',
   'Wyodrębnij wybrane strony z PDF','Potrzebujesz tylko kilku stron z dużego dokumentu? Wpisz numery stron lub zakresy, a dostaniesz nowy, mniejszy PDF.',
   ['Wgraj plik PDF (do 50 MB).','Kliknij strony na miniaturach albo wpisz zakres, np. „1-3, 5, 8-”. Zapis „8-” oznacza od strony 8 do końca.','Kliknij „Wyodrębnij strony” i pobierz nowy plik.'],
   ['Strony trafią do nowego pliku w kolejności, w jakiej je wpiszesz.','Chcesz każdą stronę w osobnym pliku? Użyj narzędzia Podziel PDF.','Oryginał nie zostaje zmieniony.'],
   [('Jak wpisać kilka zakresów?','Oddziel je przecinkami, np. 1-3, 7, 10-12.'),('Czy mogę wyodrębnić jedną stronę?','Tak, wpisz jej numer, np. 5.'),('Co, jeśli podam stronę spoza dokumentu?','Dostaniesz komunikat z liczbą stron dokumentu. Nic nie zostanie pobrane z dziennego limitu ani opłacone.')]),
 T('splitall','podziel-pdf','Podziel na strony','Każda strona w osobnym pliku (ZIP)','Podziel PDF na pojedyncze strony (ZIP)',
   'Rozdziel dokument PDF na osobne pliki, po jednym na stronę. Wynik w archiwum ZIP. Dwie operacje dziennie bezpłatnie.',
   'Podziel PDF na osobne strony','Każda strona dokumentu trafi do osobnego pliku, a całość dostaniesz w jednym archiwum ZIP.',
   ['Wgraj plik PDF (do 50 MB).','Kliknij „Podziel na strony”.','Pobierz archiwum ZIP z plikami strona-1.pdf, strona-2.pdf itd.'],
   ['Potrzebujesz kilku stron w jednym pliku? Wybierz Wyodrębnij strony.','Archiwum ZIP rozpakujesz na komputerze i na telefonie.','Oryginał nie zostaje zmieniony.'],
   [('Jak nazywają się pliki w archiwum?','strona-1.pdf, strona-2.pdf i tak dalej, zgodnie z numeracją w oryginale.'),('Czy mogę podzielić dokument co kilka stron?','Na razie dzielimy na pojedyncze strony. Fragmenty zrobisz narzędziem Wyodrębnij strony.')]),
 T('delete','usun-strony-z-pdf','Usuń strony','Usuń zbędne lub puste strony','Usuń strony z PDF online',
   'Usuń niepotrzebne strony z dokumentu PDF. Wpisz numery lub zakresy stron, np. 2, 4-6. Dwie operacje dziennie bezpłatnie.',
   'Usuń strony z pliku PDF','Pozbądź się pustych, zbędnych lub poufnych stron. Reszta dokumentu zostaje bez zmian.',
   ['Wgraj plik PDF.','Kliknij strony do usunięcia na miniaturach albo wpisz je, np. „2, 4-6”.','Kliknij „Usuń strony” i pobierz poprawiony dokument.'],
   ['Nie da się usunąć wszystkich stron naraz.','Zamiast usuwać, możesz wyodrębnić strony, które chcesz zachować.','Usunięcie dotyczy nowego pliku. Oryginał zostaje u Ciebie bez zmian.'],
   [('Czy usunięte strony da się odzyskać?','Z nowego pliku nie, ale Twój oryginał pozostaje nietknięty.'),('Jak usunąć kilka stron naraz?','Wpisz je po przecinku, np. 1, 3, 7-9.'),('Czy usunięcie zmienia numerację?','Tak, strony w nowym pliku są numerowane od początku. Numery do wydruku możesz dodać narzędziem Numeruj strony.')]),
 T('order','zmien-kolejnosc-stron-pdf','Zmień kolejność','Przestaw strony w dokumencie','Zmień kolejność stron w PDF',
   'Przestaw strony w dokumencie PDF. Podaj nową kolejność, np. 3,1,2. Dwie operacje dziennie bezpłatnie.',
   'Zmień kolejność stron w PDF','Wpisz numery stron w takiej kolejności, w jakiej mają znaleźć się w nowym dokumencie.',
   ['Wgraj plik PDF.','Przesuń strony strzałkami na miniaturach albo wpisz kolejność, np. „3,1,2”.','Kliknij „Zmień kolejność” i pobierz wynik.'],
   ['Musisz podać wszystkie strony dokumentu, każdą jeden raz.','Chcesz tylko obrócić strony? Użyj narzędzia Obróć PDF.','Chcesz pominąć część stron? Użyj Wyodrębnij strony lub Usuń strony.'],
   [('Co, jeśli pominę stronę lub powtórzę numer?','Narzędzie poinformuje Cię o błędzie, zanim cokolwiek zostanie pobrane z limitu lub opłacone.'),('Czy mogę odwrócić kolejność stron?','Tak, wpisz numery od ostatniej do pierwszej, np. 5,4,3,2,1.')]),
 T('rotate','obroc-pdf','Obróć PDF','Obróć wszystkie strony','Obróć PDF online',
   'Obróć wszystkie strony pliku PDF o 90, 180 lub 270 stopni. Dwie operacje dziennie bezpłatnie.',
   'Obróć strony w pliku PDF','Zeskanowany dokument leży bokiem? Obróć wszystkie strony naraz o 90°, 180° lub 270° i pobierz poprawiony plik.',
   ['Wgraj plik PDF.','Wybierz kąt obrotu.','Kliknij „Obróć dokument” i pobierz wynik.'],
   ['Obrót dotyczy wszystkich stron dokumentu.','Jeśli tylko część stron jest odwrócona, wyodrębnij je, obróć osobno i scal dokument ponownie.'],
   [('Czy obrót zmienia jakość?','Nie. Zmieniamy tylko orientację stron, nie przetwarzamy obrazów.'),('Czy mogę obrócić tylko jedną stronę?','Narzędzie obraca cały dokument. Pojedynczą stronę możesz wyodrębnić, obrócić i scalić z resztą.')]),
 T('mark','znak-wodny-pdf','Znak wodny','Napis na każdej stronie','Dodaj znak wodny do PDF online',
   'Dodaj ukośny, półprzezroczysty napis (np. POUFNE, KOPIA) na każdej stronie PDF. Polskie znaki obsługiwane.',
   'Dodaj znak wodny do PDF','Oznacz dokument napisem, np. POUFNE, KOPIA lub nazwą firmy. Napis pojawi się ukośnie i półprzezroczyście na każdej stronie.',
   ['Wgraj plik PDF.','Wpisz tekst znaku wodnego (do 60 znaków).','Kliknij „Dodaj znak wodny” i pobierz dokument.'],
   ['Obsługujemy polskie znaki.','Napis dopasowuje wielkość do szerokości strony.','Znak wodny zniechęca do nieuprawnionego użycia, ale nie jest zabezpieczeniem kryptograficznym.'],
   [('Czy mogę zmienić kolor lub położenie?','Na razie napis jest szary, ukośny i wyśrodkowany.'),('Czy znak wodny da się usunąć?','Technicznie tak, dlatego nie traktuj go jako zabezpieczenia dokumentu.')]),
 T('num','numeracja-stron-pdf','Numeruj strony','Numery na dole stron','Numeruj strony w PDF online',
   'Dodaj numery stron do PDF w formacie „3 / 12” na dole strony: z lewej, środka lub z prawej. Dwie operacje dziennie bezpłatnie.',
   'Dodaj numerację stron do PDF','Ponumeruj strony dokumentu w formacie „numer / liczba stron” i wybierz położenie numeru na dole strony.',
   ['Wgraj plik PDF.','Wybierz położenie numeru: lewa strona, środek lub prawa strona.','Kliknij „Dodaj numery” i pobierz dokument.'],
   ['Numeracja zaczyna się od pierwszej strony dokumentu.','Jeśli scalasz kilka plików, numeruj dopiero gotowy, scalony dokument.'],
   [('Czy mogę zacząć numerację od innej liczby?','Na razie numerujemy od 1.'),('Czy numer zakryje treść strony?','Numer jest drukowany tuż nad dolną krawędzią. Przy dokumentach z treścią do samego brzegu sprawdź wynik przed wydrukiem.')]),
 T('sign','podpisz-pdf','Podpisz PDF','Wstaw odręczny podpis','Podpisz PDF – odręczny podpis online',
   'Narysuj odręczny podpis i wstaw go na wybraną stronę PDF. To podpis w postaci obrazu, nie podpis kwalifikowany.',
   'Wstaw odręczny podpis do PDF','Narysuj podpis myszą, rysikiem lub palcem, a potem kliknij na podglądzie strony miejsce, w którym ma się znaleźć.',
   ['Wgraj plik PDF.','Narysuj podpis w polu i wpisz numer strony.','Kliknij na podglądzie strony miejsce podpisu (albo wybierz stałe położenie z listy), potem „Wstaw podpis” i pobierz dokument.'],
   ['To odręczny podpis w formie obrazu. Nie jest to kwalifikowany podpis elektroniczny ani podpis zaufany.','O tym, czy taki podpis wystarczy, decyduje odbiorca dokumentu lub przepisy dla danego rodzaju umowy.','Rysunek podpisu jest przesyłany na serwer tylko na czas operacji i usuwany razem z plikiem.'],
   [('Czy ten podpis ma moc prawną?','Odręczny podpis w postaci obrazu to nie to samo co podpis kwalifikowany lub zaufany. Skutki zależą od rodzaju dokumentu i wymagań odbiorcy. Więcej w poradniku o podpisie odręcznym i elektronicznym.'),('Gdzie pojawi się podpis?','Tam, gdzie klikniesz na podglądzie strony. Możesz też wybrać stałe położenie: dół po lewej, na środku lub po prawej.')],
   guide='podpis-odreczny-a-elektroniczny-pdf'),
 T('img','jpg-na-pdf','Obrazy → PDF','JPG, PNG, WebP lub GIF w jednym PDF','JPG na PDF – zamień obrazy w PDF online',
   'Zamień zdjęcia JPG, PNG, WebP lub GIF w jeden dokument PDF. Każdy obraz na osobnej stronie. Dwie operacje dziennie bezpłatnie.',
   'Zamień obrazy na PDF','Dodaj zdjęcia lub skany (JPG, PNG, WebP, GIF), ustaw kolejność i pobierz jeden plik PDF z obrazem na każdej stronie.',
   ['Dodaj obrazy (do 20 plików, łącznie do 60 MB).','Ustaw kolejność strzałkami.','Kliknij „Utwórz PDF” i pobierz dokument.'],
   ['Rozmiar strony dopasowuje się do obrazu.','Dużo zdjęć o wysokiej rozdzielczości daje duży PDF. Zmniejsz go potem narzędziem Zmniejsz PDF.','Pliki WebP i GIF są zamieniane na format obsługiwany w PDF.'],
   [('Czy mogę połączyć JPG i PNG w jednym PDF?','Tak, w jednym dokumencie możesz mieszać obsługiwane formaty.'),('Czy obrazy są kompresowane?','JPG i PNG trafiają do PDF bez dodatkowej kompresji. Bardzo duże obrazy skalujemy tylko do rozsądnego rozmiaru strony.'),('Co ze zdjęciami z telefonu, które wyświetlają się bokiem?','Obróć je przed dodaniem albo obróć gotowy PDF narzędziem Obróć PDF.')]),
 T('comp','zmniejsz-pdf','Zmniejsz PDF','Kompresja plików PDF','Zmniejsz PDF online – kompresja plików PDF',
   'Zmniejsz rozmiar pliku PDF. Kompresja łagodna w limicie, średnia 3,99 zł, mocna i do rozmiaru 4,99 zł. Tekst zostaje zaznaczalny.',
   'Zmniejsz rozmiar pliku PDF','Plik za duży do wysłania mailem albo do formularza? Wybierz poziom kompresji lub docelowy rozmiar. Tekst w dokumencie pozostaje zaznaczalny.',
   ['Wgraj plik PDF (do 50 MB).','Wybierz poziom kompresji albo docelowy rozmiar (200 KB – 5 MB).','Zapłać, jeśli wybrana opcja jest płatna, i pobierz mniejszy plik w ciągu 30 minut.'],
   ['Łagodna kompresja to zwykła operacja: wchodzi w dzienny limit bezpłatnych operacji.','Średnia i mocna kompresja oraz zmniejszanie do rozmiaru są płatne od razu.','Gdy plik nie zmniejszy się o co najmniej 2% (lub nie osiągnie wybranego rozmiaru), zwracamy całą płatność automatycznie.','Mocna kompresja obniża jakość obrazów. Zawsze zachowaj oryginał.'],
   [('Który poziom wybrać?','Zacznij od łagodnej. Jeśli plik nadal jest za duży, wybierz średnią, a gdy to za mało, mocną albo wskaż docelowy rozmiar.'),('Czy tekst będzie zaznaczalny po kompresji?','Tak. Zmniejszamy głównie obrazy, a tekst i czcionki zostają w dokumencie.'),('Co, jeśli plik się nie zmniejszy?','Jeśli nie uda się zmniejszyć pliku o co najmniej 2% albo osiągnąć wybranego rozmiaru, nie dostajesz pliku i automatycznie zwracamy płatność.'),('Czy jest gwarancja konkretnego rozmiaru?','Przy opcji „do zadanego rozmiaru” próbujemy kolejno coraz mocniejszych ustawień. Jeśli rozmiar nie zostanie osiągnięty, zwracamy płatność.')]),
 T('pdf2img','pdf-na-jpg','PDF → JPG/PNG','Strony PDF jako obrazy','PDF na JPG online – zamień strony PDF w obrazy',
   'Zamień strony PDF na obrazy JPG lub PNG. Wybierz jakość (DPI). Do 50 stron. Dwie operacje dziennie bezpłatnie.',
   'Zamień PDF na obrazy JPG lub PNG','Każda strona dokumentu zostanie zapisana jako osobny obraz. Dla jednej strony dostaniesz od razu plik graficzny, dla wielu archiwum ZIP.',
   ['Wgraj plik PDF (do 50 MB i do 50 stron).','Wybierz format (JPG lub PNG) i jakość w DPI.','Kliknij „Zamień na obrazy” i pobierz plik lub archiwum ZIP.'],
   ['150 DPI to dobry wybór do ekranu i e-maila, 200 DPI do wydruku.','PNG zachowuje ostre krawędzie (tekst, rysunki), a JPG daje mniejsze pliki przy zdjęciach.','Dokument ma więcej niż 50 stron? Wyodrębnij najpierw potrzebny fragment.'],
   [('Jak nazywają się pliki?','strona-1, strona-2 i tak dalej, z rozszerzeniem JPG lub PNG.'),('Czy tekst będzie zaznaczalny?','Nie. Strony stają się obrazami, więc tekst jest tylko grafiką.'),('Czy to zadziała z PDF-em zabezpieczonym hasłem?','Najpierw zdejmij hasło narzędziem Usuń hasło z PDF.')], data={'fmt':'jpg'}),
 T('unlock','usun-haslo-z-pdf','Usuń hasło','Zdejmij hasło, które znasz','Usuń hasło z PDF online (gdy znasz hasło)',
   'Zdejmij hasło z pliku PDF, jeśli je znasz. Nie łamiemy zabezpieczeń. Dwie operacje dziennie bezpłatnie.',
   'Usuń hasło z pliku PDF','Masz plik PDF chroniony hasłem i znasz to hasło? Zdejmiemy zabezpieczenie, żeby plik otwierał się bez pytania o hasło.',
   ['Wgraj zabezpieczony plik PDF.','Wpisz hasło do pliku.','Kliknij „Usuń hasło” i pobierz plik bez zabezpieczenia.'],
   ['Narzędzie działa tylko wtedy, gdy podasz poprawne hasło. Nie łamiemy i nie odgadujemy haseł.','Używaj go wyłącznie do dokumentów, do których masz prawo.','Hasło służy tylko do wykonania operacji i jest usuwane razem z plikiem.'],
   [('Co, jeśli nie pamiętam hasła?','Nie możemy pomóc: nie odzyskujemy ani nie łamiemy haseł.'),('Czy usunięcie hasła zmienia treść dokumentu?','Nie. Zmienia się tylko zabezpieczenie pliku.'),('Czy ktoś widzi moje hasło?','Przetwarza je program automatycznie na czas operacji. Nie zapisujemy go trwale ani nie przeglądamy, a po operacji jest usuwane.')],
   guide='jak-usunac-haslo-z-pdf'),
 T('protect','zabezpiecz-pdf-haslem','Zabezpiecz hasłem','Szyfrowanie AES-256','Zabezpiecz PDF hasłem online (AES-256)',
   'Ustaw hasło na pliku PDF, aby otwierał się tylko po jego wpisaniu. Szyfrowanie AES-256. Dwie operacje dziennie bezpłatnie.',
   'Zabezpiecz plik PDF hasłem','Ustaw hasło, które trzeba wpisać, aby otworzyć dokument. Używamy szyfrowania AES-256.',
   ['Wgraj plik PDF.','Wpisz i powtórz hasło (4–64 znaki).','Kliknij „Zabezpiecz plik” i pobierz chroniony dokument.'],
   ['Zapamiętaj hasło: nie możemy go odzyskać ani zresetować.','Hasło chroni otwarcie dokumentu. Plik przed zabezpieczeniem przechodzi przez nasz serwer, więc przy bardzo wrażliwych dokumentach rozważ narzędzia działające lokalnie.','Hasło nie może zaczynać się od znaków - # @.'],
   [('Jak silne jest zabezpieczenie?','Plik jest szyfrowany algorytmem AES-256. Realne bezpieczeństwo zależy od siły hasła: im dłuższe i mniej oczywiste, tym lepiej.'),('Czy mogę ustawić osobne hasło do edycji?','Na razie ustawiamy jedno hasło do otwarcia dokumentu.'),('Jak zdjąć hasło później?','Narzędziem Usuń hasło z PDF, jeśli znasz hasło.')]),
 T('imgconv','konwerter-obrazow','Konwerter obrazów','HEIC, WebP, PNG, JPG','Konwerter obrazów online: HEIC, WebP, PNG, JPG',
   'Zamień zdjęcia HEIC, WebP, PNG i GIF na JPG lub PNG. Do 20 plików naraz. Dwie operacje dziennie bezpłatnie.',
   'Zamień format obrazów','Zdjęcia z iPhone’a (HEIC), obrazy WebP, PNG lub GIF zamienisz na JPG lub PNG, które otworzy każdy program.',
   ['Dodaj obrazy (do 20 plików, łącznie do 60 MB).','Wybierz format wyjściowy: JPG lub PNG.','Kliknij „Konwertuj obrazy” i pobierz plik lub archiwum ZIP.'],
   ['Dla jednego obrazu dostaniesz od razu plik, dla wielu archiwum ZIP.','Przezroczystość przy zamianie na JPG zostanie zastąpiona białym tłem.','Zdjęcia zapisane z obrotem w metadanych są obracane automatycznie.'],
   [('Ile plików naraz?','Do 20 plików, łącznie do 60 MB.'),('Czy konwersja zmienia jakość?','JPG to format stratny. Zapisujemy go z wysoką jakością, ale oryginał warto zachować.'),('Czy zachowujecie metadane zdjęcia?','Nie gwarantujemy zachowania metadanych, takich jak lokalizacja.')], data={'fmt':'jpg'}),
]
BY = {t['key']: t for t in TOOLS}
for _k in ('split', 'delete', 'order', 'sign'):
    BY[_k]['notes'].append('Miniatury stron generuje Twoja przeglądarka. Plik trafia na serwer dopiero po kliknięciu przycisku operacji.')

def variant(key, slug, title, desc, h1, lead, steps, notes, faq, data):
    return T(key, slug, '', '', title, desc, h1, lead, steps, notes, faq, data=data, sub=True)

IMG_STEPS = ['Dodaj obrazy (do 20 plików, łącznie do 60 MB).','Wybierz format wyjściowy.','Kliknij „Konwertuj obrazy” i pobierz plik lub archiwum ZIP.']
VARIANTS = [
 variant('pdf2img','pdf-na-png','PDF na PNG online – strony PDF jako obrazy PNG','Zamień strony PDF na obrazy PNG. Ostre krawędzie tekstu i rysunków, wybór jakości w DPI. Dwie operacje dziennie bezpłatnie.',
   'Zamień PDF na obrazy PNG','PNG zachowuje ostre linie i tekst bez artefaktów kompresji. Wskaż plik PDF, a każda strona zostanie zapisana jako obraz PNG.',
   ['Wgraj plik PDF (do 50 MB i do 50 stron).','Format PNG jest ustawiony. Wybierz jakość w DPI.','Kliknij „Zamień na obrazy” i pobierz plik lub archiwum ZIP.'],
   ['PNG sprawdza się przy dokumentach z tekstem, tabelami i rysunkami.','Pliki PNG są zwykle większe niż JPG. Do zdjęć wybierz JPG.','Chcesz tylko jedną stronę? Wyodrębnij ją najpierw narzędziem Wyodrębnij strony.'],
   [('Kiedy wybrać PNG, a kiedy JPG?','PNG do tekstu i grafiki z ostrymi krawędziami, JPG do stron ze zdjęciami, gdy zależy Ci na małym rozmiarze.'),('Czy mogę zmienić format na JPG?','Tak, wybierz JPG w opcjach narzędzia.')], {'fmt':'png'}),
 variant('imgconv','heic-na-jpg','HEIC na JPG online – zdjęcia z iPhone’a','Zamień zdjęcia HEIC z iPhone’a na JPG, który otworzy każdy program. Do 20 zdjęć naraz. Dwie operacje dziennie bezpłatnie.',
   'Zamień HEIC na JPG','iPhone zapisuje zdjęcia w formacie HEIC, którego nie otwiera każdy program ani strona. Zamień je na powszechny JPG.',
   ['Dodaj zdjęcia HEIC lub HEIF (do 20 plików, łącznie do 60 MB).','Format JPG jest ustawiony. Możesz wybrać PNG.','Kliknij „Konwertuj obrazy” i pobierz plik lub archiwum ZIP.'],
   ['Obsługujemy rozszerzenia HEIC i HEIF.','JPG otworzy praktycznie każde urządzenie i program.','Zachowaj oryginały HEIC, bo JPG jest formatem stratnym.'],
   [('Dlaczego iPhone zapisuje zdjęcia jako HEIC?','To format, który zwykle daje mniejsze pliki przy podobnej jakości. Nie wszystkie programy go jednak obsługują.'),('Czy mogę zamienić HEIC na PNG?','Tak, wybierz PNG w opcjach. Pliki będą większe.')], {'fmt':'jpg'}),
 variant('imgconv','webp-na-jpg','WebP na JPG online','Zamień obrazy WebP na JPG. Do 20 plików naraz, przezroczystość zastępowana białym tłem. Dwie operacje dziennie bezpłatnie.',
   'Zamień WebP na JPG','Pobrałeś obraz w formacie WebP, a program go nie otwiera? Zamień go na JPG.',
   IMG_STEPS,
   ['WebP obsługuje wiele przeglądarek, ale nie wszystkie edytory i serwisy.','Przezroczystość zostanie zastąpiona białym tłem.','Możesz dodać wiele plików naraz.'],
   [('Czy jakość się pogorszy?','JPG to format stratny, więc minimalna utrata jakości jest możliwa. Zachowaj oryginał.'),('Czy mogę zamienić WebP na PNG?','Tak, wybierz PNG w opcjach narzędzia.')], {'fmt':'jpg'}),
 variant('imgconv','png-na-jpg','PNG na JPG online – zmniejsz rozmiar obrazu','Zamień obrazy PNG na JPG, aby zmniejszyć ich rozmiar. Do 20 plików naraz. Dwie operacje dziennie bezpłatnie.',
   'Zamień PNG na JPG','Plik PNG jest za duży? Zamień go na JPG, który przy zdjęciach zajmuje zwykle znacznie mniej miejsca.',
   IMG_STEPS,
   ['Dla zrzutów ekranu z tekstem PNG bywa ostrzejszy. Porównaj wynik.','Przezroczystość zostanie zastąpiona białym tłem.','Zachowaj oryginały PNG, jeśli mogą się jeszcze przydać.'],
   [('Czy JPG będzie mniejszy?','Przy zdjęciach zwykle tak. Przy prostych grafikach i zrzutach ekranu niekoniecznie.'),('Czy zmienia się rozdzielczość?','Nie. Zmienia się format zapisu, a wymiary obrazu zostają bez zmian.')], {'fmt':'jpg'}),
 variant('imgconv','jpg-na-png','JPG na PNG online','Zamień obrazy JPG na PNG, np. do dokumentu lub formularza wymagającego PNG. Do 20 plików naraz. Dwie operacje dziennie bezpłatnie.',
   'Zamień JPG na PNG','Potrzebujesz formatu PNG, np. do dokumentu lub formularza? Zamień JPG na PNG.',
   IMG_STEPS,
   ['PNG nie poprawia jakości zdjęcia, które już jest w JPG.','Pliki PNG są zwykle większe niż JPG.','Chcesz zamienić obrazy w PDF? Użyj narzędzia JPG na PDF.'],
   [('Czy PNG poprawi jakość JPG?','Nie. Zmienia się tylko format zapisu, szczegóły utracone wcześniej nie wracają.'),('Czy mogę dodać wiele plików?','Tak, do 20 plików łącznie do 60 MB.')], {'fmt':'png'}),
]

def target_page(slug, size_label, kb, title, desc, h1, lead, notes, faq):
    base = BY['comp']
    return T('comp', slug, '', '', title, desc, h1, lead,
      ['Wgraj plik PDF (do 50 MB).','Docelowy rozmiar jest ustawiony na ' + size_label + '. Możesz go zmienić.','Zapłać 4,99 zł i pobierz plik. Jeśli rozmiaru nie da się osiągnąć, płatność wraca automatycznie.'],
      notes, faq, level='target', tgt=str(kb), sub=True)

TARGETS = [
 target_page('zmniejsz-pdf-do-1-mb','1 MB',1024,'Zmniejsz PDF do 1 MB online',
   'Zmniejsz plik PDF do 1 MB. Próbujemy kolejno coraz mocniejszej kompresji, a jeśli się nie uda, zwracamy płatność 4,99 zł.',
   'Zmniejsz PDF do 1 MB','Formularz, portal lub system rekrutacyjny odrzuca załącznik, bo jest za duży? Wskaż 1 MB, a spróbujemy dobrać kompresję tak, żeby plik się zmieścił.',
   ['Limity załączników ustala każdy serwis. Sprawdź wymagania w instrukcji formularza.','Największy wpływ na rozmiar mają skany i zdjęcia. Dokumenty złożone niemal wyłącznie z tekstu bywają małe już na starcie.','Przy małych limitach jakość obrazów może się pogorszyć. Sprawdź czytelność wyniku.'],
   [('Czy plik na pewno będzie miał 1 MB?','Gwarantujemy tylko, że jeśli się nie uda, zwrócimy pieniądze. Wynik zależy od zawartości dokumentu.'),('Czy tekst będzie czytelny?','Tekst zostaje w dokumencie jako tekst. Obrazy i skany są zmniejszane, więc mogą być mniej ostre.')]),
 target_page('zmniejsz-pdf-do-2-mb','2 MB',2048,'Zmniejsz PDF do 2 MB online',
   'Zmniejsz plik PDF do 2 MB, np. do wysłania mailem lub do formularza online. Jeśli się nie uda, płatność 4,99 zł wraca automatycznie.',
   'Zmniejsz PDF do 2 MB','Poczta lub formularz online nie przyjmuje załącznika większego niż 2 MB? Wybierz ten rozmiar docelowy, a my dobierzemy kompresję.',
   ['Limit poczty dotyczy zwykle łącznego rozmiaru wszystkich załączników w wiadomości. Sprawdź zasady swojego dostawcy poczty.','Jeśli skanujesz dokumenty samodzielnie, ustawienie 200–300 dpi często wystarcza do czytelnego pliku.','Dla pliku, który ma już poniżej 2 MB, kompresja nie jest potrzebna.'],
   [('Czy 2 MB wystarczy do wysłania pliku mailem?','To zależy od limitu Twojej poczty i od tego, ile innych załączników dodajesz do wiadomości.'),('Czy mogę wybrać inny rozmiar?','Tak, na stronie narzędzia możesz wybrać 200 KB, 500 KB, 1 MB, 2 MB lub 5 MB.')]),
 target_page('zmniejsz-pdf-do-500-kb','500 KB',500,'Zmniejsz PDF do 500 KB online',
   'Zmniejsz plik PDF do 500 KB, gdy formularz przyjmuje bardzo małe załączniki. Jeśli się nie uda, zwracamy płatność 4,99 zł.',
   'Zmniejsz PDF do 500 KB','Niektóre formularze akceptują bardzo małe załączniki. Wskaż 500 KB, a spróbujemy zmniejszyć plik, zachowując tekst w dokumencie.',
   ['Przy tak małym limicie obrazy mogą wyraźnie stracić ostrość, więc sprawdź czytelność wyniku.','Skan wielostronicowego dokumentu w kolorze trudno zmieścić w 500 KB. Pomaga ponowne skanowanie w czerni i bieli lub w niższej rozdzielczości.','Jeśli rozmiar nie zostanie osiągnięty, zwracamy płatność i nie dostajesz pliku.'],
   [('Czy da się zmniejszyć każdy PDF do 500 KB?','Nie. Pliki z dużą liczbą zdjęć lub skanów mogą się nie zmieścić. Wtedy automatycznie zwracamy płatność.'),('Co mogę zrobić, gdy plik nadal jest za duży?','Wyodrębnij tylko potrzebne strony, usuń zbędne albo przeskanuj dokument w mniejszej rozdzielczości.')]),
]
GUIDES = [
 dict(slug='jak-zmniejszyc-pdf-do-maila', title='Jak zmniejszyć PDF, żeby wysłać go mailem', desc='Praktyczne sposoby na zmniejszenie pliku PDF przed wysłaniem mailem lub wgraniem do formularza: kompresja, skany, podział na części.',
  h1='Jak zmniejszyć PDF, żeby wysłać go mailem',
  body=[('p','Duży plik PDF najczęściej waży tyle przez obrazy: skany, zdjęcia i grafiki. Tekst zajmuje zwykle niewiele miejsca.'),
   ('h2','1. Sprawdź, skąd bierze się rozmiar'),('p','Dokument ze zdjęciami lub skanami w wysokiej rozdzielczości będzie duży, nawet jeśli ma kilka stron. Dokument z samym tekstem jest zwykle mały.'),
   ('h2','2. Użyj kompresji'),('p','Zacznij od łagodnej kompresji, a gdy to za mało, wybierz średnią albo mocną. Jeśli znasz limit, użyj opcji kompresji do zadanego rozmiaru, np. do 2 MB.'),
   ('h2','3. Skanuj mądrzej'),('p','Do dokumentów tekstowych zwykle wystarcza 200–300 dpi. Czarno-biały skan jest dużo mniejszy niż kolorowy.'),
   ('h2','4. Podziel na części'),('p','Jeśli nic nie pomaga, wyślij dokument w dwóch wiadomościach. Strony podzielisz narzędziem Wyodrębnij strony.'),
   ('p','Limity załączników zależą od dostawcy poczty, więc sprawdź je w jego pomocy.')],
  links=['zmniejsz-pdf','zmniejsz-pdf-do-2-mb','wyodrebnij-strony-pdf']),
 dict(slug='jak-polaczyc-pliki-pdf', title='Jak połączyć kilka plików PDF w jeden', desc='Jak scalić pliki PDF w jeden dokument krok po kroku: kolejność, zdjęcia, numeracja stron i rozmiar pliku.',
  h1='Jak połączyć kilka plików PDF w jeden',
  body=[('p','Scalanie przydaje się przy wnioskach, ofertach i dokumentacji, gdy odbiorca chce dostać jeden plik.'),
   ('h2','Krok po kroku'),('p','Dodaj pliki do narzędzia Scal PDF, ustaw kolejność strzałkami i pobierz wynik. Strony są kopiowane bez ponownej kompresji.'),
   ('h2','Zdjęcia i skany'),('p','Jeśli część materiałów to zdjęcia, zamień je najpierw na PDF narzędziem JPG na PDF, a potem scal wszystko razem.'),
   ('h2','Numeracja'),('p','Numeruj strony dopiero po scaleniu, wtedy numeracja będzie ciągła od pierwszej do ostatniej strony.'),
   ('h2','Rozmiar'),('p','Po scaleniu plik może być duży. Jeśli trzeba, zmniejsz go narzędziem Zmniejsz PDF.')],
  links=['scal-pdf','jpg-na-pdf','numeracja-stron-pdf']),
 dict(slug='jak-usunac-strone-z-pdf', title='Jak usunąć stronę z PDF', desc='Jak usunąć jedną lub kilka stron z pliku PDF i czym różni się usuwanie od wyodrębniania stron.',
  h1='Jak usunąć stronę z PDF',
  body=[('p','Czasem w dokumencie jest pusta strona, niepotrzebna okładka albo strona z poufnymi danymi, której nie chcesz wysyłać dalej.'),
   ('h2','Usuń strony'),('p','W narzędziu Usuń strony z PDF wpisz numery, np. „2, 4-6”. Dostaniesz nowy plik bez tych stron, a oryginał zostanie u Ciebie.'),
   ('h2','Usuwanie czy wyodrębnianie?'),('p','Jeśli zostawiasz niewiele stron, szybciej będzie je wyodrębnić. Jeśli usuwasz niewiele, użyj usuwania. Wynik jest ten sam.'),
   ('h2','Pamiętaj o oryginale'),('p','Jeśli strona zawierała dane poufne, usuń je też z oryginału lub nie przekazuj oryginału dalej.')],
  links=['usun-strony-z-pdf','wyodrebnij-strony-pdf','zmien-kolejnosc-stron-pdf']),
 dict(slug='podpis-odreczny-a-elektroniczny-pdf', title='Podpis odręczny w PDF a podpis elektroniczny', desc='Czym różni się odręczny podpis wstawiony do PDF od podpisu zaufanego i kwalifikowanego. Informacje ogólne, nie porada prawna.',
  h1='Podpis odręczny w PDF a podpis elektroniczny',
  body=[('p','Wstawienie rysunku podpisu do PDF to co innego niż podpis elektroniczny w rozumieniu prawa. Poniżej ogólne rozróżnienie. To nie jest porada prawna.'),
   ('h2','Odręczny podpis jako obraz'),('p','Narzędzie Podpisz PDF wstawia obraz narysowanego przez Ciebie podpisu na wybraną stronę. Dokument nie jest przy tym zabezpieczony kryptograficznie.'),
   ('h2','Podpis zaufany i kwalifikowany'),('p','To rozwiązania, w których tożsamość podpisującego i integralność dokumentu potwierdza się technicznie, zgodnie z odrębnymi przepisami i zasadami wydawców certyfikatów.'),
   ('h2','Co wybrać?'),('p','O tym, czy wystarczy odręczny podpis, decyduje odbiorca lub przepisy dla danej czynności. Jeśli nie masz pewności, zapytaj odbiorcę dokumentu lub prawnika.')],
  links=['podpisz-pdf']),

 dict(slug='jak-otworzyc-zdjecia-heic', title='Jak otworzyć zdjęcia HEIC z iPhone’a na komputerze', desc='Dlaczego zdjęcia z iPhone’a mają format HEIC, czemu nie wszędzie się otwierają i jak zamienić je na JPG.',
  h1='Jak otworzyć zdjęcia HEIC z iPhone’a na komputerze',
  body=[('p','HEIC to format zdjęć, którego iPhone używa domyślnie. Nie każdy program, strona internetowa ani formularz potrafi go otworzyć.'),
   ('h2','Zamień na JPG'),('p','Najprościej zamienić zdjęcia na JPG w konwerterze obrazów. Możesz dodać wiele zdjęć naraz i pobrać je w jednym archiwum ZIP.'),
   ('h2','Zmień ustawienia aparatu'),('p','W ustawieniach aparatu iPhone’a można wybrać zapis w formacie bardziej zgodnym z innymi urządzeniami. Nazwy opcji zależą od wersji systemu.'),
   ('h2','Pamiętaj'),('p','JPG to format stratny, więc zachowaj oryginały HEIC.')],
  links=['heic-na-jpg','konwerter-obrazow','jpg-na-pdf']),
 dict(slug='jak-usunac-haslo-z-pdf', title='Jak usunąć hasło z PDF, gdy je znasz', desc='Jak zdjąć hasło z pliku PDF, jeśli je znasz, i dlaczego nie da się odzyskać zapomnianego hasła.',
  h1='Jak usunąć hasło z PDF, gdy je znasz',
  body=[('p','Hasło na PDF bywa uciążliwe, gdy dokument trzeba często otwierać albo wysłać dalej. Jeśli znasz hasło, możesz je zdjąć.'),
   ('h2','Krok po kroku'),('p','Wgraj plik do narzędzia Usuń hasło z PDF, wpisz hasło i pobierz plik bez zabezpieczenia. Narzędzie działa tylko z poprawnym hasłem.'),
   ('h2','Co, jeśli nie pamiętam hasła?'),('p','Nie odzyskujemy ani nie łamiemy haseł. Skontaktuj się z osobą lub instytucją, która dokument zabezpieczyła.'),
   ('h2','Zabezpieczenie z powrotem'),('p','Gdy potrzebujesz ponownie chronić dokument, użyj narzędzia Zabezpiecz PDF hasłem.')],
  links=['usun-haslo-z-pdf','zabezpiecz-pdf-haslem']),
]

def nav_html():
    items = [('/zmniejsz-pdf','Zmniejsz PDF'),('/scal-pdf','Scal PDF'),('/cennik','Cennik'),('/poradniki','Poradniki')]
    return '<header class="site"><div class="wrap"><a class="brand" href="/">Warsztat PDF</a><nav aria-label="Główna">' + ''.join('<a href="%s">%s</a>' % i for i in items) + '</nav></div></header>'

def footer_html():
    tl = ''.join('<li><a href="/%s">%s</a></li>' % (t['slug'], E(t['nav'])) for t in TOOLS)
    info = [('cennik','Cennik'),('poradniki','Poradniki'),('o-nas','O nas'),('bezpieczenstwo-plikow','Bezpieczeństwo plików'),('regulamin','Regulamin'),('polityka-prywatnosci','Polityka prywatności')]
    il = ''.join('<li><a href="/%s">%s</a></li>' % i for i in info)
    return ('<footer class="site"><div class="wrap"><strong>Narzędzia</strong><ul>' + tl + '</ul><strong>Informacje</strong><ul>' + il + '</ul>'
            '<p>Usługodawca: K-D Sp. z o.o., Al. Zwycięstwa 241/13, 81-521 Gdynia, NIP 5862430327, KRS 0001240474. Kontakt: <a href="mailto:%s">%s</a></p></div></footer>' % (EMAIL, EMAIL))

def head(title, desc, path, robots=None, ld=None):
    if SOON and not robots: robots = 'noindex, nofollow'
    full = title + ' | Warsztat PDF' if 'Warsztat PDF' not in title else title
    url = SITE + path
    h = ['<meta charset="utf-8">','<meta name="viewport" content="width=device-width, initial-scale=1">','<title>%s</title>' % E(full),
         '<meta name="description" content="%s">' % E(desc),'<link rel="canonical" href="%s">' % url,
         '<link rel="icon" href="/favicon.svg" type="image/svg+xml">','<link rel="stylesheet" href="/site.css">']
    if robots: h.append('<meta name="robots" content="%s">' % robots)
    else:
        for k, v in [('og:title', full),('og:description', desc),('og:type','website'),('og:url', url),('og:locale','pl_PL'),('og:site_name','Warsztat PDF'),('og:image', SITE + '/og.png')]:
            h.append('<meta property="%s" content="%s">' % (k, E(v)))
        h.append('<meta name="twitter:card" content="summary_large_image">')
    for j in (ld or []):
        h.append('<script type="application/ld+json">%s</script>' % json.dumps(j, ensure_ascii=False))
    return '\n'.join(h)

def page(path, title, desc, main, body_attr='', robots=None, ld=None, script=False):
    return ('<!DOCTYPE html>\n<html lang="pl">\n<head>\n' + head(title, desc, path, robots, ld) + '\n</head>\n<body%s>\n' % body_attr + nav_html() +
            '\n<main class="wrap">\n' + main + '\n</main>\n' + footer_html() + ('\n<script src="/app.js"></script>' if script else '') + '\n</body>\n</html>\n')

def write(path, content):
    fn = os.path.join(PUB, path.strip('/') or 'index') + ('' if path.endswith(('.xml','.txt')) else '.html')
    os.makedirs(os.path.dirname(fn), exist_ok=True)
    open(fn, 'w', encoding='utf-8').write(content)

def crumbs(name, path):
    return {'@context':'https://schema.org','@type':'BreadcrumbList','itemListElement':[
        {'@type':'ListItem','position':1,'name':'Warsztat PDF','item':SITE + '/'},{'@type':'ListItem','position':2,'name':name,'item':SITE + path}]}

def tool_page(t):
    path = '/' + t['slug']
    others = [x for x in TOOLS if x['slug'] != t['slug']]
    links = ''.join('<li><a href="/%s">%s</a></li>' % (x['slug'], E(x['nav'])) for x in others)
    extra = ''
    if t.get('guide'):
        extra = '<p>Zobacz też: <a href="/%s">%s</a>.</p>' % (t['guide'], E(next(g['title'] for g in GUIDES if g['slug'] == t['guide'])))
    if t['key'] == 'comp':
        extra += '<p>Szukasz konkretnego limitu? <a href="/zmniejsz-pdf-do-500-kb">500 KB</a> · <a href="/zmniejsz-pdf-do-1-mb">1 MB</a> · <a href="/zmniejsz-pdf-do-2-mb">2 MB</a>. Poradnik: <a href="/jak-zmniejszyc-pdf-do-maila">jak zmniejszyć PDF, żeby wysłać go mailem</a>.</p>'
    main = ('<h1>%s</h1><p class="lead">%s</p>\n%s\n<div class="content"><h2>Jak to zrobić</h2><ol>%s</ol><h2>Dobrze wiedzieć</h2><ul>%s</ul><h2>Najczęstsze pytania</h2>%s<h2>Cena</h2><p>%s Szczegóły w <a href="/cennik">cenniku</a>.</p>%s<h2>Inne narzędzia</h2><ul>%s</ul></div>'
            % (E(t['h1']), E(t['lead']), (SOON_PANEL if SOON else PANEL), ''.join('<li>%s</li>' % E(s) for s in t['steps']), ''.join('<li>%s</li>' % E(n) for n in t['notes']),
               ''.join('<h3>%s</h3><p>%s</p>' % (E(q), E(a)) for q, a in t['faq']), E(PRICE_NOTE), extra, links))
    dat = dict({'level': t['level'], 'tgt': t['tgt']} if t.get('level') else {}, **t.get('data', {}))
    attrs = '' if SOON else ' data-tool="%s"' % t['key'] + ''.join(' data-%s="%s"' % kv for kv in dat.items())
    ld = [{'@context':'https://schema.org','@type':'WebApplication','name':t['h1'],'url':SITE + path,'applicationCategory':'UtilitiesApplication','operatingSystem':'Any','inLanguage':'pl',
           'publisher':{'@type':'Organization','name':'K-D Sp. z o.o.'}}, crumbs(t['h1'], path)]
    write(path, page(path, t['title'], t['desc'], main, attrs, ld=ld, script=not SOON))

def info(slug, title, desc, h1, body):
    path = '/' + slug
    write(path, page(path, title, desc, '<h1>%s</h1><div class="content">%s</div>' % (E(h1), body), ld=[crumbs(h1, path)]))

def build():
    if PUB != PUB_SRC:
        os.makedirs(PUB, exist_ok=True)
        for f in ('site.css', 'favicon.svg', 'og.png', '.htaccess'):
            shutil.copy(os.path.join(PUB_SRC, f), os.path.join(PUB, f))
        if not SOON: shutil.copy(os.path.join(PUB_SRC, 'app.js'), os.path.join(PUB, 'app.js'))
    for t in TOOLS + TARGETS + VARIANTS: tool_page(t)
    # strona główna
    cards = ''.join('<a class="card" href="/%s"><b>%s</b><span>%s</span></a>' % (t['slug'], E(t['nav']), E(t['short'])) for t in TOOLS)
    faq = [('Czy korzystanie jest bezpłatne?','Dwie operacje standardowe dziennie są bezpłatne. Kolejne kosztują 3,99 zł. Kompresja średnia kosztuje 3,99 zł, a mocna i do zadanego rozmiaru 4,99 zł.'),
           ('Co dzieje się z moimi plikami?','Są przetwarzane automatycznie na naszym serwerze i usuwane: pliki wejściowe zaraz po operacji, wynik po 30 minutach, a najpóźniej po 60 minutach od przesłania.'),
           ('Jak mogę zapłacić?','Płatności obsługuje PayU: BLIK, szybkie przelewy online i karty płatnicze.'),
           ('Co, jeśli operacja się nie uda?','Nie zostanie wliczona do limitu, a płatność wróci automatycznie.')]
    main = ('<h1>Narzędzia do plików PDF online</h1><p class="lead">Scalaj, dziel, obracaj, numeruj, podpisuj i zmniejszaj pliki PDF. Dwie operacje dziennie są bezpłatne, kolejne kosztują 3,99 zł. Pliki są usuwane po 30 minutach.</p>'
            '<div class="cards">' + cards + '</div><div class="content"><h2>Zmniejsz PDF do konkretnego rozmiaru</h2><p>Formularz odrzuca załącznik? Zobacz: <a href="/zmniejsz-pdf-do-500-kb">PDF do 500 KB</a>, <a href="/zmniejsz-pdf-do-1-mb">PDF do 1 MB</a>, <a href="/zmniejsz-pdf-do-2-mb">PDF do 2 MB</a>.</p>'
            '<h2>Konwersje obrazów i PDF</h2><p><a href="/pdf-na-jpg">PDF na JPG</a> · <a href="/pdf-na-png">PDF na PNG</a> · <a href="/heic-na-jpg">HEIC na JPG</a> · <a href="/webp-na-jpg">WebP na JPG</a> · <a href="/png-na-jpg">PNG na JPG</a> · <a href="/jpg-na-png">JPG na PNG</a> · <a href="/jpg-na-pdf">JPG na PDF</a></p>'
            '<h2>Dlaczego Warsztat PDF</h2><ul><li>Serwis prowadzi polska spółka z siedzibą w Gdyni.</li><li>Jasny cennik i płatność BLIK-iem, bez konta i abonamentu.</li><li>Pliki usuwane po 30 minutach, bez reklam i śledzących ciasteczek.</li><li>Automatyczny zwrot, gdy operacja się nie uda. Szczegóły: <a href="/bezpieczenstwo-plikow">bezpieczeństwo plików</a>.</li></ul>'
            '<h2>Najczęstsze pytania</h2>' + ''.join('<h3>%s</h3><p>%s</p>' % (E(q), E(a)) for q, a in faq) + '</div>')
    org = {'@context':'https://schema.org','@type':'Organization','name':'Warsztat PDF','legalName':'K-D spółka z ograniczoną odpowiedzialnością','url':SITE + '/','email':EMAIL,
           'address':{'@type':'PostalAddress','streetAddress':'Al. Zwycięstwa 241/13','postalCode':'81-521','addressLocality':'Gdynia','addressCountry':'PL'},'vatID':'PL5862430327'}
    write('/', page('/', 'Warsztat PDF – narzędzia do plików PDF online', 'Scalaj, dziel, obracaj, podpisuj i zmniejszaj pliki PDF online. Dwie operacje dziennie bezpłatnie, pliki usuwane po 30 minutach.', main, ld=[org]))
    # cennik
    rows = [('Operacja standardowa – dwie pierwsze w ciągu doby','bezpłatnie'),('Operacja standardowa – każda kolejna w ciągu doby','3,99 zł'),('Kompresja średnia','3,99 zł'),('Kompresja mocna','4,99 zł'),('Kompresja do zadanego rozmiaru','4,99 zł')]
    info('cennik','Cennik','Cennik Warsztatu PDF: dwie operacje dziennie bezpłatnie, kolejne 3,99 zł. Kompresja średnia 3,99 zł, mocna i do rozmiaru 4,99 zł.','Cennik',
      '<p>Ceny są w złotych i zawierają podatek VAT. Nie ma abonamentu ani konta: płacisz tylko za operacje, które wykonujesz po wyczerpaniu darmowego limitu.</p><table><tr><th>Usługa</th><th>Cena brutto</th></tr>' +
      ''.join('<tr><td>%s</td><td>%s</td></tr>' % r for r in rows) +
      '</table><h2>Co jest operacją standardową?</h2><p>Scalanie, wyodrębnianie stron, podział na strony, usuwanie stron, zmiana kolejności, obracanie, znak wodny, numeracja, podpis, obrazy na PDF, PDF na obrazy, usuwanie i ustawianie hasła, konwersja obrazów oraz łagodna kompresja.</p>'
      '<h2>Jak liczymy limit dzienny?</h2><p>Limit dotyczy doby według czasu polskiego i jest liczony dla adresu IP w postaci skrótu, który usuwamy po zmianie doby. Osoby korzystające z tej samej sieci (np. w firmie) mogą dzielić limit. Nieudana operacja nie zużywa limitu.</p>'
      '<h2>Płatność i zwroty</h2><p>Płatności obsługuje PayU (BLIK, szybkie przelewy, karty). Gdy operacji płatnej nie da się wykonać albo kompresja nie zmniejszy pliku o co najmniej 2% (lub nie osiągnie wybranego rozmiaru), zwracamy całą kwotę automatycznie. Zasady: <a href="/regulamin">regulamin</a>.</p>')
    info('o-nas','O nas','Warsztat PDF prowadzi K-D Sp. z o.o. z Gdyni. Dane firmy, kontakt i zasady działania serwisu.','O Warsztacie PDF',
      '<p>Warsztat PDF to proste narzędzia do codziennych zadań z plikami PDF, z uczciwym cennikiem i bez zbędnych kont.</p><h2>Kto prowadzi serwis</h2><p>K-D spółka z ograniczoną odpowiedzialnością, Al. Zwycięstwa 241/13, 81-521 Gdynia, KRS 0001240474, NIP 5862430327, REGON 544702353, kapitał zakładowy 5 000 zł.</p>'
      '<h2>Zasady</h2><ul><li>Jasny cennik i brak ukrytych opłat.</li><li>Krótkie przechowywanie plików i automatyczne usuwanie.</li><li>Zwrot pieniędzy, gdy usługa nie zadziała.</li></ul><h2>Kontakt</h2><p><a href="mailto:%s">%s</a></p>' % (EMAIL, EMAIL))
    info('bezpieczenstwo-plikow','Bezpieczeństwo plików – co robimy z Twoimi dokumentami','Jak chronimy pliki w Warsztacie PDF: szyfrowane połączenie, automatyczne przetwarzanie, usuwanie po 30 minutach, brak śledzących ciasteczek.','Jak chronimy Twoje pliki',
      '<h2>Krok po kroku</h2><ol><li>Plik jest przesyłany szyfrowanym połączeniem (HTTPS).</li><li>Przetwarza go program automatycznie. Nikt z naszego zespołu nie otwiera Twoich dokumentów.</li><li>Plik wejściowy usuwamy zaraz po wykonaniu operacji.</li><li>Wynik jest dostępny do pobrania przez 30 minut, a potem go usuwamy. Najpóźniej po 60 minutach od przesłania nie ma po pliku śladu na serwerze.</li><li>Nie robimy kopii zapasowych plików użytkowników.</li></ol>'
      '<h2>Podgląd stron i hasła</h2><p>Miniatury stron (przy wyodrębnianiu, usuwaniu, zmianie kolejności i podpisie) generuje Twoja przeglądarka. Plik trafia na nasz serwer dopiero po kliknięciu przycisku wykonania operacji. Hasła podane w narzędziach do hasła służą tylko do wykonania operacji, nie trafiają do zapisu zamówienia i są usuwane razem z plikiem.</p>'
      '<h2>Czego nie robimy</h2><ul><li>Nie używamy ciasteczek reklamowych ani analitycznych.</li><li>Nie sprzedajemy ani nie udostępniamy plików.</li></ul><h2>O czym warto pamiętać</h2><p>Pliki są przetwarzane na naszym serwerze, a nie na Twoim urządzeniu. Przy szczególnie wrażliwych dokumentach rozważ narzędzia działające lokalnie na Twoim komputerze.</p>'
      '<p>Dane płatnicze przekazujesz bezpośrednio operatorowi płatności (PayU) i nie widzimy numeru Twojej karty. Szczegóły: <a href="/polityka-prywatnosci">polityka prywatności</a>.</p>')
    # poradniki
    for g in GUIDES:
        body = ''.join('<%s>%s</%s>' % (tg, E(tx), tg) for tg, tx in g['body'])
        names = {t['slug']: (t['nav'] or t['h1']) for t in TOOLS + TARGETS + VARIANTS}
        body += '<h2>Powiązane narzędzia</h2><ul>' + ''.join('<li><a href="/%s">%s</a></li>' % (s, E(names[s])) for s in g['links']) + '</ul>'
        info(g['slug'], g['title'], g['desc'], g['h1'], body)
    info('poradniki','Poradniki o plikach PDF','Praktyczne poradniki: jak zmniejszyć, połączyć i podpisać plik PDF oraz usunąć z niego strony.','Poradniki',
      '<ul>' + ''.join('<li><a href="/%s">%s</a></li>' % (g['slug'], E(g['title'])) for g in GUIDES) + '</ul>')
    # zamówienie (noindex) i 404
    write('/zamowienie', page('/zamowienie', 'Twoje zamówienie', 'Status zamówienia.', '<h1>Twoje zamówienie</h1><section class="panel"><p id="st">Sprawdzam zamówienie…</p></section>', ' data-page="order"', robots='noindex, nofollow', script=not SOON))
    write('/404', page('/404', 'Nie znaleziono strony', 'Nie znaleziono strony.', '<h1>Nie znaleziono strony</h1><p class="lead">Takiej strony nie ma. Wróć do <a href="/">listy narzędzi</a>.</p>', robots='noindex'))
    # sitemap + robots
    paths = ['/'] + ['/' + t['slug'] for t in TOOLS + TARGETS + VARIANTS] + ['/cennik','/poradniki','/o-nas','/bezpieczenstwo-plikow','/regulamin','/polityka-prywatnosci'] + ['/' + g['slug'] for g in GUIDES]
    pr = lambda p: '1.0' if p == '/' else '0.9' if p in ('/zmniejsz-pdf','/scal-pdf') else '0.5' if p in ('/regulamin','/polityka-prywatnosci','/o-nas') else '0.7'
    write('/sitemap.xml', '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' +
          ''.join('<url><loc>%s%s</loc><lastmod>%s</lastmod><priority>%s</priority></url>\n' % (SITE, p, DATE, pr(p)) for p in paths) + '</urlset>\n')
    write('/robots.txt', 'User-agent: *\nDisallow: /\n' if SOON else 'User-agent: *\nAllow: /\nDisallow: /api/\nDisallow: /zamowienie\n\nSitemap: %s/sitemap.xml\n' % SITE)
    # dokumenty prawne z Markdown (pandoc) w wspólnym układzie
    open('/tmp/_before.html', 'w', encoding='utf-8').write(nav_html() + '\n<main class="wrap content">')
    open('/tmp/_after.html', 'w', encoding='utf-8').write('</main>\n' + footer_html())
    for slug, ptitle, d in [('regulamin','Regulamin','Regulamin serwisu Warsztat PDF: zasady korzystania, cennik, płatności, zwroty, odstąpienie od umowy i reklamacje.'),
                            ('polityka-prywatnosci','Polityka prywatności','Polityka prywatności serwisu Warsztat PDF: jakie dane przetwarzamy, jak długo, komu je przekazujemy i jakie prawa Ci przysługują.')]:
        subprocess.run(['pandoc','-f','markdown','-t','html5','-s','--css','/site.css','-B','/tmp/_before.html','-A','/tmp/_after.html',
                        '--metadata','pagetitle=%s | Warsztat PDF' % ptitle,'--metadata','description=%s' % d,
                        os.path.join(ROOT,'docs','zrodla',slug + '.md'),'-o',os.path.join(PUB, slug + '.html')], check=True)
        p = os.path.join(PUB, slug + '.html'); s = open(p, encoding='utf-8').read()
        extra = '<link rel="canonical" href="%s/%s">\n<link rel="icon" href="/favicon.svg" type="image/svg+xml">\n' % (SITE, slug)
        if SOON: extra += '<meta name="robots" content="noindex, nofollow">\n'
        open(p, 'w', encoding='utf-8').write(s.replace('</head>', extra + '</head>', 1))
    print('Zbudowano stron:', len(paths) + 2)

if __name__ == '__main__':
    build()
