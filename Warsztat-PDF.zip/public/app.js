'use strict';
const $ = (s) => document.querySelector(s);
const PDF = '.pdf,application/pdf';
const STD = '3,99 zł';
const T = {
  merge: { n: 'Scal PDF', d: 'Połącz kilka plików w jeden', multi: 1, acc: PDF, go: 'Scal pliki' },
  split: { n: 'Wyodrębnij strony', d: 'Wybierz zakres, np. 1-3, 5', acc: PDF, go: 'Wyodrębnij strony' },
  splitall: { n: 'Podziel na strony', d: 'Każda strona osobno, w ZIP', acc: PDF, go: 'Podziel na strony' },
  delete: { n: 'Usuń strony', d: 'Np. 2, 4-6', acc: PDF, go: 'Usuń strony' },
  order: { n: 'Zmień kolejność stron', d: 'Podaj nową kolejność', acc: PDF, go: 'Zmień kolejność' },
  rotate: { n: 'Obróć PDF', d: 'Wszystkie strony naraz', acc: PDF, go: 'Obróć dokument' },
  mark: { n: 'Znak wodny', d: 'Ukośny napis na każdej stronie', acc: PDF, go: 'Dodaj znak wodny' },
  num: { n: 'Numeruj strony', d: 'Numer na dole strony', acc: PDF, go: 'Dodaj numery' },
  sign: { n: 'Podpisz PDF', d: 'Narysuj podpis i wstaw go', acc: PDF, go: 'Wstaw podpis' },
  img: { n: 'Obrazy → PDF', d: 'JPG, PNG, WebP, GIF', multi: 1, acc: 'image/*', go: 'Utwórz PDF' },
  comp: { n: 'Kompresuj PDF', d: 'Zmniejsz rozmiar pliku', acc: PDF, go: 'Zmniejsz plik' },
  pdf2img: { n: 'PDF → JPG/PNG', d: 'Strony jako obrazy', acc: PDF, go: 'Zamień na obrazy' },
  unlock: { n: 'Usuń hasło z PDF', d: 'Gdy znasz hasło', acc: PDF, go: 'Usuń hasło' },
  protect: { n: 'Zabezpiecz hasłem', d: 'Szyfrowanie AES-256', acc: PDF, go: 'Zabezpiecz plik' },
  imgconv: { n: 'Konwerter obrazów', d: 'HEIC, WebP, PNG, JPG', multi: 1, acc: 'image/*,.heic,.heif', go: 'Konwertuj obrazy' }
};
let tool = document.body.dataset.tool || 'merge', files = [], left = null, sigInk = false;
const msg = (t, e) => { $('#msg').textContent = t; $('#msg').className = 'msg' + (e ? ' err' : ''); };

async function refreshQuota() {
  try { const j = await (await fetch('/api/quota')).json(); left = j.left; } catch { left = null; }
  wire();
}
// cena dla bieżącego wyboru: null = bezpłatnie
function price() {
  if (tool === 'comp') { const q = $('#q') && $('#q').value; if (q === 'mid') return '3,99 zł'; if (q === 'high' || q === 'target') return '4,99 zł'; }
  return left === 0 ? STD : null;
}
function wire() {
  const p = price();
  if ($('#consL')) $('#consL').style.display = p ? 'grid' : 'none';
  $('#go').textContent = p ? 'Zamawiam i płacę (' + p + ')' : T[tool].go + ' (bezpłatnie)';
  $('#quota').textContent = left === null ? '' : left > 0
    ? 'Dziś zostało Ci ' + left + ' z 2 bezpłatnych operacji (nie dotyczy kompresji średniej i mocnej). Kolejne: ' + STD + ' za operację.'
    : 'Dzienny limit bezpłatnych operacji został wykorzystany. Kolejna operacja: ' + STD + '.';
}
function drawTools() {
  if (!$('#tools')) return;
  $('#tools').innerHTML = '';
  for (const k in T) {
    const b = document.createElement('button'); b.className = 'tool'; b.setAttribute('aria-pressed', k === tool);
    b.innerHTML = '<b>' + T[k].n + '</b><span>' + T[k].d + '</span>';
    b.onclick = () => { tool = k; files = []; msg(''); render(); };
    $('#tools').append(b);
  }
}
const L = (l, h) => '<label>' + l + h + '</label>';
function render() {
  drawTools(); const t = T[tool];
  $('#inp').accept = t.acc; $('#inp').multiple = !!t.multi;
  $('#dropT').textContent = t.multi ? 'Upuść pliki tutaj lub kliknij, aby wybrać' : 'Upuść plik tutaj lub kliknij, aby wybrać';
  $('#dropS').textContent = t.multi ? 'Kolejność na liście to kolejność w wyniku (do 20 plików, łącznie do 60 MB)' : 'Jeden plik, do 50 MB';
  const ul = $('#list'); ul.innerHTML = '';
  files.forEach((f, i) => {
    const li = document.createElement('li');
    li.innerHTML = '<span class="n"></span><small>' + (f.size / 1024).toFixed(0) + ' KB</small>';
    li.querySelector('.n').textContent = f.name;
    if (t.multi) [['↑', -1], ['↓', 1]].forEach(([s, d]) => {
      const b = document.createElement('button'); b.className = 'ic'; b.textContent = s; b.title = d < 0 ? 'Przesuń wyżej' : 'Przesuń niżej';
      b.onclick = () => { const j = i + d; if (j < 0 || j >= files.length) return; [files[i], files[j]] = [files[j], files[i]]; render(); };
      li.append(b);
    });
    const x = document.createElement('button'); x.className = 'ic'; x.textContent = '✕'; x.title = 'Usuń';
    x.onclick = () => { files.splice(i, 1); render(); }; li.append(x); ul.append(li);
  });
  const o = $('#opts'); let h = '';
  if (tool === 'split') h = L('Strony do wyodrębnienia', '<input type="text" id="rng" placeholder="np. 1-3, 5, 8-">');
  if (tool === 'delete') h = L('Strony do usunięcia', '<input type="text" id="rng" placeholder="np. 2, 4-6">');
  if (tool === 'order') h = L('Nowa kolejność (każda strona raz)', '<input type="text" id="ord" placeholder="np. 3,1,2">');
  if (tool === 'rotate') h = L('Kąt obrotu', '<select id="ang"><option value="90">90° w prawo</option><option value="180">180°</option><option value="270">90° w lewo</option></select>');
  if (tool === 'mark') h = L('Tekst znaku wodnego', '<input type="text" id="wm" value="POUFNE" maxlength="60">');
  if (tool === 'num') h = L('Pozycja numeru', '<select id="pos"><option value="c">Dół, środek</option><option value="r">Dół, prawa strona</option><option value="l">Dół, lewa strona</option></select>');
  if (tool === 'comp') {
    const dl = document.body.dataset.level || 'mid', dt = document.body.dataset.tgt || '2048', sel = (v) => v === dl ? ' selected' : '';
    h = L('Poziom kompresji', '<select id="q"><option value="light"' + sel('light') + '>Łagodna – standardowa operacja</option><option value="mid"' + sel('mid') + '>Średnia – 3,99 zł</option><option value="high"' + sel('high') + '>Mocna – 4,99 zł</option><option value="target"' + sel('target') + '>Do zadanego rozmiaru – 4,99 zł</option></select>') +
      '<label id="tgtL" style="display:' + (dl === 'target' ? 'grid' : 'none') + '">Docelowy rozmiar<select id="tgt">' +
      [['200', '200 KB'], ['500', '500 KB'], ['1024', '1 MB'], ['2048', '2 MB'], ['5120', '5 MB']].map(([v, n]) => '<option value="' + v + '"' + (v === dt ? ' selected' : '') + '>' + n + '</option>').join('') + '</select></label>';
  }
  if (tool === 'sign') h = L('Strona', '<input type="text" id="pg" value="1" size="4" style="min-width:0">') +
    L('Miejsce', '<select id="sp"><option value="r">Dół, prawo</option><option value="l">Dół, lewo</option><option value="c">Dół, środek</option><option value="p">Wskazane na podglądzie</option></select>') +
    '<canvas id="pad" width="300" height="110" aria-label="Pole podpisu"></canvas><button class="ic" id="clr" style="width:auto;padding:0 12px">Wyczyść</button><div id="signpv" style="flex-basis:100%"></div>';
  const f0 = document.body.dataset.fmt || 'jpg', fmtSel = '<select id="fmt"><option value="jpg"' + (f0 === 'jpg' ? ' selected' : '') + '>JPG</option><option value="png"' + (f0 === 'png' ? ' selected' : '') + '>PNG</option></select>';
  if (tool === 'pdf2img') h = L('Format', fmtSel) + L('Jakość (DPI)', '<select id="dpi"><option value="100">100 – podgląd, e-mail</option><option value="150" selected>150 – standard</option><option value="200">200 – wysoka, do wydruku</option></select>');
  if (tool === 'imgconv') h = L('Format wyjściowy', fmtSel);
  if (tool === 'unlock') h = L('Hasło do pliku', '<input type="password" id="pw" autocomplete="off" maxlength="128">');
  if (tool === 'protect') h = L('Hasło (4–64 znaki)', '<input type="password" id="pw" autocomplete="new-password" maxlength="64">') + L('Powtórz hasło', '<input type="password" id="pw2" autocomplete="new-password" maxlength="64">') + '<div class="priv" style="flex-basis:100%">Zapamiętaj hasło: nie da się go odzyskać ani zresetować.</div>';
  h += '<label id="consL" style="display:none;grid-template-columns:auto 1fr;align-items:start;gap:8px;color:var(--ink);max-width:600px"><input type="checkbox" id="cons"><span>Zapoznałem(-am) się z <a href="/regulamin" target="_blank">Regulaminem</a> i <a href="/polityka-prywatnosci" target="_blank">Polityką prywatności</a>. Wyrażam zgodę na rozpoczęcie świadczenia usługi przed upływem terminu odstąpienia od umowy i przyjmuję do wiadomości, że po jej pełnym wykonaniu utracę prawo odstąpienia od umowy.</span></label>';
  o.innerHTML = h;
  if (tool === 'sign') initPad();
  if ($('#q')) $('#q').onchange = () => { $('#tgtL').style.display = $('#q').value === 'target' ? 'grid' : 'none'; wire(); };
  $('#go').disabled = !files.length; wire(); buildThumbs();
}
function initPad() {
  sigInk = false; const c = $('#pad'), x = c.getContext('2d'); x.lineWidth = 2.5; x.lineCap = 'round'; x.strokeStyle = '#12302b'; let d = false;
  const pt = (e) => { const r = c.getBoundingClientRect(); return [(e.clientX - r.left) * c.width / r.width, (e.clientY - r.top) * c.height / r.height]; };
  c.onpointerdown = (e) => { d = true; c.setPointerCapture(e.pointerId); x.beginPath(); x.moveTo(...pt(e)); };
  c.onpointermove = (e) => { if (!d) return; x.lineTo(...pt(e)); x.stroke(); sigInk = true; };
  c.onpointerup = () => { d = false; };
  $('#clr').onclick = () => { x.clearRect(0, 0, c.width, c.height); sigInk = false; };
}
// ---- podgląd stron: pdf.js działa wyłącznie w przeglądarce, plik trafia na serwer dopiero po kliknięciu operacji ----
let pdfLoad = null, thumbToken = 0, sel = new Set(), ordArr = [], sigPos = null, signDoc = null;
function loadPdfjs() {
  if (window.pdfjsLib) { if (!window.pdfjsLib.GlobalWorkerOptions.workerSrc) window.pdfjsLib.GlobalWorkerOptions.workerSrc = '/vendor/pdf.worker.min.js'; return Promise.resolve(window.pdfjsLib); }
  if (!pdfLoad) pdfLoad = new Promise((res, rej) => {
    const s = document.createElement('script'); s.src = '/vendor/pdf.min.js';
    s.onload = () => { window.pdfjsLib.GlobalWorkerOptions.workerSrc = '/vendor/pdf.worker.min.js'; res(window.pdfjsLib); }; s.onerror = rej; document.head.append(s);
  });
  return pdfLoad;
}
const toRanges = (set) => { const a = [...set].sort((x, y) => x - y), out = []; for (let i = 0; i < a.length;) { let j = i; while (j + 1 < a.length && a[j + 1] === a[j] + 1) j++; out.push(j > i ? (a[i] + 1) + '-' + (a[j] + 1) : String(a[i] + 1)); i = j + 1; } return out.join(', '); };
function parseSel(str, n) {
  const out = new Set();
  for (const part of str.split(',')) {
    const t = part.trim(), m = t.match(/^(\d*)\s*-\s*(\d*)$/); let a, b;
    if (m) { a = +m[1] || 1; b = +m[2] || n; } else if (/^\d+$/.test(t)) { a = b = +t; } else continue;
    for (let i = Math.max(1, a); i <= Math.min(b, n); i++) out.add(i - 1);
  }
  return out;
}
async function renderPage(doc, pn, width) {
  const pg = await doc.getPage(pn), v0 = pg.getViewport({ scale: 1 }), vp = pg.getViewport({ scale: width / v0.width });
  const c = document.createElement('canvas'); c.width = Math.ceil(vp.width); c.height = Math.ceil(vp.height);
  await pg.render({ canvasContext: c.getContext('2d'), viewport: vp }).promise;
  return { c, w: v0.width, h: v0.height };
}
async function buildThumbs() {
  const box = $('#thumbs'); if (!box) return;
  const token = ++thumbToken, f = files[0];
  box.innerHTML = ''; sel = new Set(); ordArr = []; sigPos = null; signDoc = null;
  if (!f || !['split', 'delete', 'order', 'sign'].includes(tool)) return;
  try {
    const lib = await loadPdfjs();
    const doc = await lib.getDocument({ data: new Uint8Array(await f.arrayBuffer()), isEvalSupported: false }).promise;
    if (token !== thumbToken) return;
    if (tool === 'sign') { signDoc = doc; await signPreview(); if ($('#pg')) $('#pg').oninput = () => signPreview(); return; }
    const n = doc.numPages, lim = Math.min(n, 60), inp = $(tool === 'order' ? '#ord' : '#rng');
    if (tool === 'order' && n > lim) { box.innerHTML = '<p class="priv">Dokument ma ' + n + ' stron – podgląd dostępny do 60 stron. Wpisz kolejność ręcznie.</p>'; return; }
    box.innerHTML = '<p class="priv" id="thhint">Ładowanie podglądu stron…</p>';
    const grid = document.createElement('div'); grid.className = 'thumbs-grid'; box.append(grid);
    const cvs = [], cells = [];
    for (let i = 0; i < lim; i++) {
      const { c } = await renderPage(doc, i + 1, 110); if (token !== thumbToken) return;
      cvs.push(c);
      if (tool !== 'order') {
        const cell = document.createElement('div'); cell.className = 'th'; cell.append(c); const sp = document.createElement('span'); sp.textContent = i + 1; cell.append(sp);
        cell.onclick = () => { sel.has(i) ? sel.delete(i) : sel.add(i); cell.classList.toggle('on', sel.has(i)); inp.value = toRanges(sel); };
        cells.push(cell); grid.append(cell);
      }
    }
    if (tool === 'order') {
      ordArr = cvs.map((_, i) => i); inp.value = ordArr.map((i) => i + 1).join(',');
      const draw = () => {
        grid.innerHTML = '';
        ordArr.forEach((idx, pos) => {
          const cell = document.createElement('div'); cell.className = 'th'; cell.style.cursor = 'default'; cell.append(cvs[idx]);
          const sp = document.createElement('span'); sp.textContent = idx + 1; cell.append(sp);
          const mv = document.createElement('div'); mv.className = 'mv';
          [['◀', -1], ['▶', 1]].forEach(([s, d]) => { const b = document.createElement('button'); b.type = 'button'; b.className = 'ic'; b.textContent = s; b.title = d < 0 ? 'Przesuń wcześniej' : 'Przesuń później';
            b.onclick = () => { const j = pos + d; if (j < 0 || j >= ordArr.length) return; [ordArr[pos], ordArr[j]] = [ordArr[j], ordArr[pos]]; inp.value = ordArr.map((k) => k + 1).join(','); draw(); }; mv.append(b); });
          cell.append(mv); grid.append(cell);
        });
      };
      draw();
      inp.oninput = () => { const arr = inp.value.split(/[,\s]+/).filter(Boolean).map((x) => +x - 1); if (arr.length === n && new Set(arr).size === n && arr.every((i) => i >= 0 && i < n)) { ordArr = arr; draw(); } };
      $('#thhint').textContent = 'Użyj strzałek, aby przesunąć stronę. Możesz też wpisać kolejność ręcznie.';
    } else {
      inp.oninput = () => { sel = parseSel(inp.value, n); cells.forEach((c, i) => c.classList.toggle('on', sel.has(i))); };
      $('#thhint').textContent = (tool === 'delete' ? 'Kliknij strony, które chcesz usunąć.' : 'Kliknij strony, które chcesz zachować.') + (n > lim ? ' Podgląd pierwszych 60 stron z ' + n + ', pozostałe wpisz ręcznie.' : '');
    }
  } catch (e) { box.innerHTML = '<p class="priv">Podgląd stron jest niedostępny dla tego pliku. Możesz wpisać numery stron ręcznie.</p>'; }
}
async function signPreview() {
  const box = $('#signpv'); if (!box || !signDoc) return;
  const pn = Math.max(1, Math.min(signDoc.numPages, parseInt($('#pg').value, 10) || 1));
  const { c, w, h } = await renderPage(signDoc, pn, 480);
  box.innerHTML = '<p class="priv">Kliknij na podglądzie, aby wskazać miejsce podpisu.</p>';
  const wrap = document.createElement('div'); wrap.style.cssText = 'position:relative;display:inline-block;max-width:100%';
  c.style.cssText = 'max-width:100%;height:auto;border:1px solid var(--line);cursor:crosshair;background:#fff';
  const mk = document.createElement('div'); mk.style.cssText = 'position:absolute;border:2px dashed #0f766e;background:rgba(15,118,110,.18);pointer-events:none;display:none';
  const place = () => {
    if (!sigPos) { mk.style.display = 'none'; return; }
    const sw = Math.min(180, w * 0.4), sh = sw * 110 / 300;
    mk.style.display = 'block'; mk.style.width = (sw / w * 100) + '%'; mk.style.height = (sh / h * 100) + '%';
    mk.style.left = ((sigPos.x - sw / w / 2) * 100) + '%'; mk.style.top = ((sigPos.y - sh / h / 2) * 100) + '%';
  };
  c.onclick = (e) => { const r = c.getBoundingClientRect(); sigPos = { x: (e.clientX - r.left) / r.width, y: (e.clientY - r.top) / r.height }; $('#sp').value = 'p'; place(); };
  wrap.append(c, mk); box.append(wrap); place();
}
function add(list) {
  const a = [...list].filter((f) => tool === 'img' ? f.type.startsWith('image/') : tool === 'imgconv' ? (f.type.startsWith('image/') || /\.(heic|heif)$/i.test(f.name)) : /\.pdf$/i.test(f.name));
  if (!a.length) { msg('Ten typ pliku nie pasuje do wybranego narzędzia.', 1); return; }
  files = T[tool].multi ? files.concat(a) : [a[0]]; msg(''); render();
}
// obsługa wgrywania i wysyłki – tylko na stronach narzędzi
if (document.body.dataset.tool) {
const drop = $('#drop');
drop.onclick = () => $('#inp').click();
drop.onkeydown = (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); $('#inp').click(); } };
$('#inp').onchange = (e) => { add(e.target.files); e.target.value = ''; };
['dragover', 'dragenter'].forEach((v) => drop.addEventListener(v, (e) => { e.preventDefault(); drop.classList.add('over'); }));
['dragleave', 'drop'].forEach((v) => drop.addEventListener(v, (e) => { e.preventDefault(); drop.classList.remove('over'); }));
drop.addEventListener('drop', (e) => add(e.dataTransfer.files));

function params() {
  const v = (id) => $(id) ? $(id).value : '';
  return { ranges: v('#rng'), order: v('#ord'), angle: v('#ang'), text: v('#wm'), pos: v('#pos'), page: v('#pg'), place: v('#sp'), level: v('#q'), targetKb: v('#tgt'), password: v('#pw'), format: v('#fmt'), dpi: v('#dpi'), x: sigPos ? sigPos.x : '', y: sigPos ? sigPos.y : '' };
}
$('#go').onclick = async () => {
  const g = $('#go'); g.disabled = true;
  try {
    const p = price();
    if (p && !$('#cons').checked) throw Error('Zaznacz zgodę, aby kontynuować.');
    if (tool === 'sign' && !sigInk) throw Error('Najpierw narysuj podpis w polu.');
    if (tool === 'protect' && $('#pw').value !== $('#pw2').value) throw Error('Hasła nie są takie same.');
    if (tool === 'sign' && $('#sp').value === 'p' && !sigPos) throw Error('Kliknij na podglądzie strony, aby wskazać miejsce podpisu.');
    if (tool === 'comp' && $('#q').value === 'target' && files[0].size <= +$('#tgt').value * 1024) throw Error('Ten plik jest już mniejszy niż wybrany rozmiar docelowy.');
    const fd = new FormData();
    fd.append('tool', tool); fd.append('params', JSON.stringify(params())); fd.append('consent', p ? '1' : '0');
    files.forEach((f) => fd.append('files', f));
    if (tool === 'sign') fd.append('sig', await new Promise((r) => $('#pad').toBlob(r, 'image/png')), 'podpis.png');
    msg('Przesyłanie…');
    const r = await fetch('/api/process', { method: 'POST', body: fd }); let j = {}; try { j = await r.json(); } catch { /* brak JSON */ }
    if (r.status === 402) { left = 0; wire(); throw Error('Dzienny limit bezpłatnych operacji został wykorzystany. Zaznacz zgodę i kliknij „Zamawiam i płacę”.'); }
    if (!r.ok || !(j.url || j.id)) throw Error(j.error || 'Nie udało się wykonać operacji.');
    location.href = j.url;
  } catch (e) { msg(e.message || 'Wystąpił błąd.', 1); }
  g.disabled = !files.length;
};
}

// ekran zamówienia (/zamowienie/ID) i inicjalizacja strony narzędzia
if (document.body.dataset.tool) { render(); refreshQuota(); }
if (document.body.dataset.page === 'order') {
  const q = new URLSearchParams(location.search), id = location.pathname.split('/').filter(Boolean).pop(), panel = document.querySelector('.panel');
  const back = () => { const a = document.createElement('a'); a.href = '/'; a.textContent = 'Wróć do narzędzi'; panel.append(' ', a); };
  if (q.get('error')) { panel.textContent = 'Płatność nie została dokończona. Nic nie zostało pobrane z Twojego konta, a plik zostanie usunięty z serwera. '; back(); }
  else if (!/^[a-f0-9]{48}$/.test(id || '')) { panel.textContent = 'Nieprawidłowy adres zamówienia. '; back(); }
  else {
    let n = 0;
    const t = setInterval(async () => {
      n++;
      try {
        const j = await (await fetch('/api/order/' + id)).json();
        if (j.status === 'ready') {
          clearInterval(t);
          const sz = j.tool === 'comp' ? ' Rozmiar pliku zmniejszony z ' + j.before + ' KB do ' + j.after + ' KB.' : '';
          panel.innerHTML = '<p>Gotowe.' + sz + '</p><a class="go" style="display:inline-block;text-decoration:none" href="/api/download/' + id + '">Pobierz plik</a><p class="priv">Link działa do ' + new Date(j.expires).toLocaleTimeString('pl-PL') + '. Potem plik zostanie usunięty z naszego serwera.</p><p><a href="/">Wróć do narzędzi</a></p>';
        } else if (['refunded', 'failed', 'gone', 'error'].includes(j.status)) { clearInterval(t); panel.textContent = j.message + ' '; back(); }
        else if (n > 90) { clearInterval(t); document.getElementById('st').textContent = 'Przetwarzanie trwa dłużej niż zwykle. Odśwież stronę za chwilę.'; }
        else document.getElementById('st').textContent = j.status === 'awaiting_payment' ? 'Czekam na potwierdzenie płatności…' : 'Przetwarzam plik…';
      } catch { /* ponów */ }
    }, 2000);
  }
}
